var webpack = require('webpack');
var path    = require('path');

module.exports = {
    entry : {
        a: './src/a.js'
    },
    output : {
        path: path.join(__dirname, "build"),
        filename : "[name].js"
    },
    externals : {
        react : "React"
    },
    resolve: {
        extensions: ['', '.js', '.jsx']
    },
    module: {
        loaders: [{
            test: /\.js$/,
            loader: 'babel-loader'
        }, {
            test: /\.jsx$/,
            loader: 'babel-loader!jsx-loader?harmony'
        }]
    }
};
