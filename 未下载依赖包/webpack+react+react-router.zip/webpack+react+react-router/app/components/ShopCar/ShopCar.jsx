/**
 * Created by Meric on 2016/10/11.
 */
import React from 'react'

class ShopCar extends React.Component {
    render() {
        return <div>
            ShopCar
        </div>
    }
}

export default ShopCar