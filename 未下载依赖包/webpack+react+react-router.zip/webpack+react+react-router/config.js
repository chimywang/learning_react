/**
 * Created by Meric on 2016/10/17.
 */
var App = {
    Config: {
        api_site_prefix: 'http://localhost:4000/'
    },
    API: {
        user: {
            userList: 'user/list',
            signup:'signup'
        }
    }
}

module.exports = App