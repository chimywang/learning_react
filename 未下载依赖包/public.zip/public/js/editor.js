/**
 * Created by hhx on 2016/4/13.
 */
const Router = ReactRouter.Router,
    Link = ReactRouter.Link,
    Route = ReactRouter.Route,
    browserHistory = ReactRouter.browserHistory;

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return decodeURI(r[2]);
    return null;
}

//类别选择框
const SelectCategory = React.createClass({
    render(){
        let data = this.props.data;
        let resuNode = data.map(u=> {
            if (this.props.selectId === u.Id) {
                return (
                    <option selected="selected" value={u.Id}>{u.CName}</option>
                );
            } else {
                return (
                    <option value={u.Id}>{u.CName}</option>
                );
            }
        });

        return (<select className="selectCategory" name={this.props.name}>{resuNode}</select>);
    }
});

//完整的html内容
const Html = React.createClass({
    getInitialState: function () {
        return {article: {}, listCategory: []};
    },
    componentDidMount: function () {
        //初始化编辑器
        if (!CKEDITOR.inited) {
            CKEDITOR.inited = true;

            CKEDITOR.replace('editor', {
                language: 'zh-cn',
                uiColor: '#efecf4',
                height: 600
            });

            CKEDITOR.on('instanceReady', function (e) {
                CKEDITOR.isLoaded = true
                if (CKEDITOR.content) {
                    CKEDITOR.instances.editor.setData(CKEDITOR.content);
                }
            });
        }

        let aid = this.props.params.aid;

        //获取数据
        $.get("/articleApi/getDetailWithCategories/" + aid, null, data=> {
            this.setState({article: data.articleInfo, listCategory: data.listCategories});

            //如果ck已经加载完毕 则直接放内容进去
            if (CKEDITOR.isLoaded) {
                CKEDITOR.instances.editor.setData(data.articleInfo.AContent);
            } else { // 如果内容没有加载完 把内容到存起来
                CKEDITOR.content = data.articleInfo.AContent;
            }
        });
    },
    //提交
    handSubmit: function () {
        submitContent(this.props.params.aid, data=> {
            if (data.affectedRows > 0) {
                alert("保存成功");
                if (this.props.params.aid) {
                    window.location.reload();
                } else {
                    window.location = "/editor/edit/" + data.insertId;
                }
            } else {
                alert("保存失败!");
            }
        });
    },
    handleValueChange: function (e) {
        e = e || event;
        let article = this.state.article;
        article.ATitle = event.target.value;
        this.setState({article: article});
    },
    //处理上传图片逻辑
    handUploadImg: function () {
        let domFile = document.querySelector("#fileImg");
        if (domFile.files.length < 1) {
            alert("请选择一张图片");
        }
        utls.uploadImgToQiniu(domFile.files[0], resu=> {
            if (resu.state === 0) {
                CKEDITOR.instances.editor.insertHtml("<img src='" + resu.msg + "' />");
            } else {
                alert("上传失败" + resu.msg);
            }
        });
    },
    render(){
        let cid = this.props.params.cid;

        return (
            <div className="container">
                <form id="form1">
                    <div className="container-top">
                        <a href="/index.html">返回</a>
                        <h1>写博客</h1>
                    </div>

                    <div className="container-categorys">
                        <span>选择类别:</span>
                        <SelectCategory data={this.state.listCategory} cid={cid}
                                        name={"Fk_CategoryId"}
                                        selectId={this.state.article.Fk_CategoryId}></SelectCategory>
                    </div>

                    <div className="container-title">
                        <span>标题</span>: <input name="ATitle" type="text" id="txtAtitle" placeholder="输入标题"
                                                value={this.state.article.ATitle } onChange={this.handleValueChange}/>
                    </div>
                    <div className="container-img">
                        <span>选择文件:</span> <input id="fileImg" type="file" accept="image/*"/>
                        <input onClick={this.handUploadImg} type="button" value="上传"/>
                    </div>
                    {/*编辑器部分*/}
                    <textarea name="editor" className="editor"></textarea>
                    <br/>
                    <input type="button" value="保存" className="btn-submit" onClick={this.handSubmit}/>
                </form>
                <div className="container-bottom">bottom</div>
            </div>
        );
    }
});

//初始化信息
(function init() {
    ReactDOM.render((
        <Router history={browserHistory}>
            <Route path="/editor">
                <Route path="add" component={Html}>
                </Route>
                <Route path="edit/:aid" component={Html}> </Route>
            </Route>
        </Router>
    ), document.querySelector("#contentContainer"));
}());

const submitContent = function (aid, callback) {
    var article = {};

    article = utls.setFormToModel(document.querySelector("#form1"));
    article.AContent = CKEDITOR.instances.editor.getData();
    //摘要
    article.ASummary = CKEDITOR.instances.editor.document.getBody().getText().substring(0, 220);
    article.Id = aid;

    $.ajax({
        contentType: "application/json;charset=UTF-8",
        url: "/articleApi/set",
        data: JSON.stringify({"article": article}),
        success: function (data) {
            callback(data);
        },
        dataType: "json",
        method: "POST",
        processData: false
    });
}

