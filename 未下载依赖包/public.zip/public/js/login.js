/**
 * Created by hhx on 2016/4/16.
 */
$("#btnLogin").click(function (e) {
    e = e || event;
    e.stopPropagation();
    e.preventDefault();

    let form1 = document.querySelector("#form1");
    let user = utls.setFormToModel(form1);
    utls.sendPost("/user/login", {user: user}, (data)=> {
        if (data.state === 0) {
            //存到seesionstorage中
            var cookie = document.cookie;
            utls.setCurrentUser(data.msg);
            if(window.parentLogin){
                window.parentLogin();
            }else{
                window.location = "/index.html";
            }
        } else {
            alert("账号或密码错误!");
        }
    });

    return false;
});