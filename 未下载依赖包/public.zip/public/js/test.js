let Router = ReactRouter.Router,
    Route = ReactRouter.Route,
    Link = ReactRouter.Link,
    browserHistory = ReactRouter.browserHistory;

const App = React.createClass({
    render(){
        return (<div>appapapapap</div>);
    }
});
const About = React.createClass({
    render(){
        return (<div>aboutaboutaboutaboutabout</div>);
    }

});

const Article = React.createClass({
    render(){
        return (<div>测试</div>);
    }
});

const Users = React.createClass({
    render() {
        return (
            <div>
                <h1>Users</h1>
                <div className="master">
                    <ul>
                        {/* use Link to route around the app */}
                        {this.state.users.map(user => (
                            <li key={user.id}><Link to={`/user/${user.id}`}>{user.name}</Link></li>
                        ))}
                    </ul>
                </div>
                <div className="detail">
                    {this.props.children}
                </div>
            </div>
        )
    }
})

const User = React.createClass({
    componentDidMount() {
        this.setState({
            // route components are rendered with useful information, like URL params
            user: findUserById(this.props.params.userId)
        })
    },

    render() {
        return (
            <div>
                <h2>{this.state.user.name}</h2>
                {/* etc. */}
            </div>
        )
    }
});

ReactDOM.render((
    <Router history={browserHistory}>
        <Route path="/test.html" component={App}> </Route>
    </Router>
), document.body);
