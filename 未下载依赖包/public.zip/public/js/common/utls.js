/**
 * Created by hhx on 2016/4/16.
 */
let utls = {};

utls.qiniuUrl = "http://7xswfo.com2.z0.glb.clouddn.com/";

utls.sendPost = (url, data, callback)=> {
    $.ajax({
        contentType: "application/json;charset=UTF-8",
        url: url,
        data: JSON.stringify(data),
        success: function (data) {
            callback(data);
        },
        dataType: "json",
        method: "POST",
        processData: false
    });
}

//将form中的内容转换为实体
utls.setFormToModel = function (domForm) {
    var model = {};
    for (var i = 0; i < domForm.length; i++) {
        var u = domForm[i];
        if (u.name) {
            model[u.name] = u.value;
        }
    }
    return model;
};

//设置当前用户
utls.setCurrentUser = user => {
    window.sessionStorage.setItem("user", JSON.stringify(user));
}

//获取到当前用户
utls.getCurrentUser = function () {
    let resu = null;
    let sessiontoken = this.getCookie("sessiontoken");
    if (!sessiontoken || sessiontoken.length < 10) {
        this.showLoginPage();
        return resu;
    }

    let userStr = window.sessionStorage.getItem("user");

    if (!userStr || userStr.length < 5) {
        //获取用户
        $.get("/user/getcurrent", {}, data=> {
            if (data.state !== 0) {
                this.showLoginPage();
            } else {
                resu = data.msg;
                this.setCurrentUser(resu);
                alert("重新登陆了一道,再试一盘刚才的操作");
            }
        });
    } else {
        resu = JSON.parse(userStr);
    }

    return resu;
}

//显示登陆框
utls.showLoginPage = function () {
    if (!window.loginPageContainer) {
        let container = document.createElement("div");
        container.className = "loginPage";
        container.style.position = "fixed";
        container.style.width = "100%";
        container.style.height = "100%";
        container.style.zIndex = 99999;
        container.style.backgroundColor = "rgba(0,0,0,0.6)";
        container.style.top = 0;
        container.style.left = 0;


        let div1 = document.createElement("div");
        div1.style.height = "80%";
        div1.style.width = "70%";
        div1.style.margin = "0 auto";
        div1.style.backgroundColor = "red";
        div1.style.top = "50%";
        div1.style.transform = "translateY(-50%)";
        div1.style.position = "relative";

        let iframe = document.createElement("iframe");
        iframe.src = "/login.html";
        iframe.style.width = "100%";
        iframe.style.height = "100%";
        iframe.style.border = "none";

        div1.appendChild(iframe);


        container.appendChild(div1);
        document.body.appendChild(container);
        window.loginPageContainer = container;

        iframe.onload = function () {
            window.frames[0].parentLogin = function () {
                //关闭登录框
                container.style.display = "none";
            }
        }
    } else {
        window.loginPageContainer.style.display = "block";
    }
}

utls.getCookie = function (name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg)) return decodeURIComponent(arr[2]);
    else return null;
}

//获取md5值 (引用sparkmd5)
utls.getMd5 = (obj)=> {
    var spark = new SparkMD5();
    if (typeof obj === "string") {
        spark.append(obj);
    } else {
        spark.appendBinary(obj);
    }

    return spark.end();
};

utls.getQueryString = function(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return decodeURIComponent(r[2]); return null;
}

//上传图片到七牛服务器 回调参数: {state:0, msg:图片名字}
utls.uploadImgToQiniu = (file, callback)=> {
    $.get("/qiniuApi/getToken", {}, function (data) {
        if (data.state === 0) {
            var token = data.msg.token;
            var key = data.msg.fileName;
            Qiniu_upload(file, token, key, callback);
        }else{
            callback(data);
        }
    });
}

var Qiniu_upload = function (f, token, key, callback) {
    var Qiniu_UploadUrl = "http://up.qiniu.com";
    var xhr = new XMLHttpRequest();
    xhr.open('POST', Qiniu_UploadUrl, true);
    var formData;
    formData = new FormData();
    if (key !== null && key !== undefined) formData.append('key', key);
    formData.append('token', token);
    formData.append('file', f); 


    xhr.onreadystatechange = function (response) {
        if (xhr.readyState == 4 && xhr.status == 200 && xhr.responseText != "") {
            var blkRet = JSON.parse(xhr.responseText);
            callback({state: 0, msg: utls.qiniuUrl +  blkRet.key});
        } else if (xhr.status != 200 && xhr.responseText) {
            callback({state: -1, msg: xhr.responseText});
        }
    };
    xhr.send(formData);
};

window.utls = utls;