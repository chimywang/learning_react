"use strict";
const Router = ReactRouter.Router,
    Link = ReactRouter.Link,
    Route = ReactRouter.Route,
    browserHistory = ReactRouter.browserHistory;

let loadingToast = document.querySelector("#loadingToast");

let currentPage = 1;

//----------------------------------------左边文章部分 开始----------------------------------------

//显示日期和类别
const ArticleDateBox = React.createClass({
    render(){
        this.props.CreateTime = getDateStringByTimtamp(this.props.CreateTime);
        return (
            <div className="article-dateAndCategory">
                <div className="article-icon"></div>
                <span>{this.props.CreateTime}</span>
                <div className="article-icon"></div>
                <span>{this.props.ACategory}</span>
            </div>);
    }
});

const ArticleBox = React.createClass({
    render: function () {
        return (<div className="article-container">
                <a href={"/index/articleDetail/" + this.props.Id}>
                    <div className="article-title">{this.props.ATitle}</div>
                </a>
                <ArticleDateBox CreateTime={this.props.CreateTime} ACategory={this.props.ACategory}></ArticleDateBox>
                <div className="article-content">

                    <span dangerouslySetInnerHTML={{__html: this.props.children}}></span>
                </div>
                <div className="article-readall"><a href={"/index/articleDetail/" + this.props.Id}>阅读全文</a></div>
            </div>
        );
    }
});

//文章[列表]
let ArticleList = React.createClass({
    //初始化state的方法 固定的函数
    getInitialState: function () {
        return {data: []};
    },
    componentDidMount: function () { //控件加载完毕开始获取数据
        let _this = this;
        if (this.state.data && this.state.data.length < 1 && currentPage === 1) {
            getArticleData(1, function (data) {
                _this.setState({data: data});
            });
        }
    },
    handNextPage: function (e) {
        e = e || event;
        e.preventDefault();
        e.stopPropagation();
        getArticleData(++currentPage, data=> {
            this.setState({data: data});
        });
    },
    handPrePage: function (e) {
        e = e || event;
        e.preventDefault();
        e.stopPropagation();
        if (currentPage <= 1) {
            return;
        }
        getArticleData(--currentPage, data=> {
            this.setState({data: data});
        });
    },
    render: function () {
        let resuNode = this.state.data.map(u=> {
            return (
                <ArticleBox ATitle={u.ATitle} CreateTime={u.CreateTime} ACategory={u.ACategory} Id={u.Id}>
                    {u.ASummary}
                </ArticleBox>
            );
        });

        let page;
        if (currentPage <= 1) {
            page = <div className="article-pages"><a href="#" onClick={this.handNextPage}>下一页</a></div>
        } else {
            page = <div className="article-pages"><a href="#" onClick={this.handPrePage}>上一页</a> <a href="#"
                                                                                                    onClick={this.handNextPage}>下一页</a>
            </div>
        }
        return ( <span> {resuNode}
            {page}
        </span>);
    }
});

//----------------------------------------左边文章部分 结束----------------------------------------

//右边的列表数据部件
let RightDataList = React.createClass({
    render: function () {
        let resuNode = this.props.data.map(u=> {
            return (
                <li><a href={this.props.actionPage + u.Id}>{u[this.props.fieldName]}</a></li>
            );
        });

        return (<ul className="right-listData"> {resuNode}
        </ul>);
    }
});

//文章详情
let ArticleDetail = React.createClass({
    componentWillMount: function () { //控件加载完毕开始获取数据
        setLoadingState(1);
        var aid = this.props.params.aid;
        $.get("/articleApi/getDetail/" + aid, {}, data=> {
            this.setState({data: data});
            setLoadingState(0);
        });
    },
    //删除文章编辑
    handDeleteArticle: function (e) {
        e = e || event;
        let aid = this.state.data.Id;
        if (confirm("不要手抖,是不是要干掉他??")) {
            if (utls.getCurrentUser()) {
                $.post("/articleApi/delete/" + aid, {}, function (data) {
                    if (data.state === 1004) {
                        alert(data.msg);
                    } else {
                        alert("该目标已经被干掉!");
                    }
                });
            }
        }
    },
    //跳转到文章编辑
    handEditArticle: function () {
        let goPage = "/editor/edit/" + this.state.data.Id;
        if (utls.getCurrentUser()) {
            window.location = goPage;
        }
    },

    render: function () {
        if (!this.state) {
            return (<div></div>);
        }

        var createDateString = getDateStringByTimtamp(this.state.data.CreateTime);

        return (<div className="articleDetail-Container">
            <div className="article-title">{this.state.data.ATitle}</div>
            <ArticleDateBox CreateTime={this.state.data.CreateTime}
                            ACategory={this.state.data.ACategory}></ArticleDateBox>
            <div className="articleDetail-content">
                &nbsp; &nbsp; &nbsp;
                <span dangerouslySetInnerHTML={{__html:  this.state.data.AContent}}></span>
            </div>
            <div className="article-createtime">
                发布时间: <span>{createDateString}</span> <a href="javascript:" onClick={this.handEditArticle}>编辑 </a>
                <a href="javascript:" onClick={this.handDeleteArticle}> 删除</a>
            </div>
        </div>);
    }
});


//根据路由进行渲染
ReactDOM.render((
    <Router history={browserHistory}>
        <Route path="/" component={ArticleList}>
            <Route path="index.html" component={ArticleList}></Route>
        </Route>
        <Route path="/index/articleDetail/:aid" component={ArticleDetail}> </Route>
    </Router>
), document.querySelector(".leftContainer"));

document.addEventListener("DOMContentLoaded", ()=> {
    //初始化右边的分类信息
    $.get("/categoryApi/getAllList", {}, data=> {
        ReactDOM.render(<RightDataList data={data} actionPage={"/index.html?categoryId="}
                                       fieldName={"CName"}></RightDataList>, document.querySelector(".spanListCategory"));
    });

    //初始化右边的最新文章
    $.get("/articleApi/getNewArticle", {}, data=> {
        ReactDOM.render(<RightDataList data={data} actionPage={"/index/articleDetail/"}
                                       fieldName={"ATitle"}></RightDataList>, document.querySelector(".spanListNewArticle"));
    });
});

//加载文章列表数据
function getArticleData(pageIndex, callback) {
    setLoadingState(1);

    $.get("/articleApi/getlist/" + pageIndex + window.location.search, {}, (data)=> {
        setLoadingState(0);
        callback(data);
    });
}

function setLoadingState(state) {
    if (state) {
        loadingToast.style.display = "block"; //开始获取数据时显示加载框
    } else {
        loadingToast.style.display = "none"; //开始获取数据时显示加载框
    }

}

function getDateStringByTimtamp(timetamp) {
    let date = new Date((timetamp + 28800) * 1000); //UTC时间戳加上8小时的时差

    return date.getFullYear() + "/" + (date.getMonth() + 1) + "/" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes();
}

//搜索按钮点击事件
function btnSearchClick() {
    let keyword = document.querySelector("#txtSearchKey").value;
    window.location = "/index.html?keywords=" + encodeURI(keyword);
}