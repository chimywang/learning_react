// enable babel
require('babel/register');
// require gulp entry
require('./gulp');
