import {render} from 'react-dom';
import React from 'react';
import App from './app/index';
import './main.css';

render(<App />, document.getElementById('root'));
