/**
 * Created by chenjs on 16/3/17.
 */
import reqwest from 'reqwest';
import cc from '../config.js';

const fetch = (m, p)=> {
    const c = cc;

    reqwest({
        url: c.serverUrl + p.api,
        method: m,
        type: 'json',
        data: p.d || '',
        withCredentials: true,
        crossOrigin: true,
        success: (x)=> {
            if (x.status && x.status.code && x.status.message) {
                if (x.status.code === 10000) {
                    p.s && p.s(x);
                } else {
                    p.e && p.e(x.status.message);
                    console.log(x.status.message);
                }
            }

        },
        error: (x)=> {
            p && p.e && p.e('网络有问题,请重试');
        }
    });
};

const fetchStream = (m, p)=> {
    const c = cc;

    reqwest({
        url: c.serverUrl + p.api,
        method: m,
        data: p.d || '',
        withCredentials: true,
        crossOrigin: true,
        success: (x)=> {
            if (x.status == 200) {
                p.s && p.s(x);
            } else {
                p.e && p.e(x.status.message);
            }
        },
        error: (x)=> {
            p && p.e && p.e('网络有问题,请重试');
        }
    });
};

export const get = p => {
    fetch('get', p);
};

export const post = p => {
    fetch('post', p);
};

export const patch = p => {
    fetch('patch', p);
};

export const put = p => {
    fetch('put', p);
};

export const delet = p => {
    fetch('delete', p);
};

export const getStream = p => {
    fetchStream('get', p);
};
