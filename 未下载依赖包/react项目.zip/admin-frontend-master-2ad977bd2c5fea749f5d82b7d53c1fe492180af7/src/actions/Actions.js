/**
 * Created by chenjs on 16/3/17.
 */

import Reflux from 'reflux';

export const articleAction = Reflux.createActions([
    'getArticles',
    'getArticle',
    'editArticle'
]);

