/**
 * Created by chenjs on 16/3/17.
 */

export default {
    //serverUrl: 'http://123.56.76.181/api/v1/'
    serverUrl: 'http://10.0.54.175/api/v1/'
    //serverUrl: 'http://10.0.55.71/api/v1/'
};
