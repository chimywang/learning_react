import React from 'react';
import Router from 'react-routing/src/Router';

//const routes = [
//    require('../routes/login'),
//    require('../routes/home'),
//];

const router = new Router(on => {

    on('/', () => {
        const Login = require('./components/Login/Login');
        return <Login />;
    });
});

export default router;
