/**
 * Created by qinmy on 16/3/11.
 */
import {Form, Radio, Modal} from 'antd';
import React, {Component} from 'react';
import MyTextInput from '../Common/MyTextInput';
import {get, post} from '../../helper/httpHelper';
const FormItem = Form.Item;
const RadioGroup = Radio.Group;

export default class UserInfo extends Component {

    constructor() {
        super();
        this.state =
        {
            visible: false
        };
        this.username = '';
        this.email = '';
        this.type = '0';
        this.status = 'true';
    }

    showModal() {
        this.setState({
            visible: true
        });
    }

    handleOk() {
        this.setState({
            visible: false
        });
        this.username = this.refs.userName.getValue();
        this.email = this.refs.address.getValue();
        this.executeCreate();
    }

    handleCancel(e) {
        console.log(e);
        this.setState({
            visible: false
        });
    }

    onChangeType(e) {
        console.log('radio checked', e.target.value);
        this.type = e.target.value;
    }

    onChangeStatus(e) {
        console.log('radio checked', e.target.value);
        this.status = e.target.value;

    }

    executeCreate() {

        const self = this;
        console.log(' 传的参 ' + this.username + this.email + this.type + this.status);
        post({
            api: 'users',
            d: {username: this.username, email: this.email, userrole: this.type, is_active: this.status},
            s: x=>{

                self.setState({visible: false});
                var is_email_verified = x.data.is_email_verified;
                var password_reset_on = x.data.password_reset_on;
                var updated_on = x.data.updated_on;
                var is_migrate = x.data.is_migrate;
                var username = x.data.username;
                var email = x.data.email;
                var is_advanced = x.data.is_advanced;
                var is_superuser = x.data.is_superuser;
                var is_active = x.data.is_active;
                var created_by = x.data.created_by;
                var updated_by = x.data.updated_by;
                var id = x.data.id;
                var password = x.data.password;
                var created_on = x.data.created_on;
                self.props.newCallBack && self.props.newCallBack();

                Modal.success({
                    title: '请牢记',
                    content:(
                        <div>
                            <p>登陆邮箱：{email}</p>
                            <p>密码：{password}</p>
                        </div>
                    )
                });
            },

            e: (m)=>{
                Modal.error({
                    title: '提示',
                    content: m
                });
            }
        });
    }

        render() {
            const formItemLayout = {
                labelCol: {span: 6},
                wrapperCol: {span: 14},
            };

            return (
                <div>
                    <Modal title="新建用户" visible={this.state.visible}
                           onOk={this.handleOk.bind(this)} onCancel={this.handleCancel.bind(this)}>
                        <Form horizontal>
                            <FormItem
                                {...formItemLayout}
                                label="用户：">
                                <MyTextInput placeholder="请输入用户名称" ref="userName" />
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="邮箱：">
                                <MyTextInput placeholder="请输入用户邮箱" ref="address"/>
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="角色：">
                                <RadioGroup defaultValue = "0" onChange={this.onChangeType.bind(this)}>
                                    <Radio key="a" value="0">初级运营</Radio>
                                    <Radio key="b" value="1">高级运营</Radio>
                                    <Radio key="c" value="2">管理员</Radio>
                                </RadioGroup>
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="状态：">
                                <RadioGroup defaultValue = "true" onChange={this.onChangeStatus.bind(this)}>
                                    <Radio key="a" value="true">激活</Radio>
                                    <Radio key="b" value="false">关闭</Radio>
                                </RadioGroup>
                            </FormItem>
                        </Form>
                    </Modal>
                </div>

            );
        }
}
