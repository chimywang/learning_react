/**
 * Created by qinmy on 16/3/14.
 */
/**
 * Created by qinmy on 16/3/11.
 */
import {Modal} from 'antd';
import React, {Component} from 'react';
import {get, post} from '../../helper/httpHelper';

export default class ResetPwd extends Component {

    constructor() {
        super();
        this.state =
        {
            visible: false,
            id: null
        };
    }

    showModal(id) {
        this.setState({
            visible: true,
            id: id
        });
    }

    handleOk() {
        console.log('点击了确定' + this.state.id);
        this.setState({
            visible: false
        });
        this.resetPwd();
    }

    handleCancel(e) {
        console.log(e);
        this.setState({
            visible: false
        });
    }

    resetPwd(params) {
        const self = this;
        post({
            api: 'users/:' + this.state.id + '/reset_password',
            d: params ? params : '',
            s: x=> {
                self.setState({
                    count: x.data.count,
                    data: x.data.rows
                });
            },
            e: ()=> {
                Modal.error({
                    title: '提示',
                    content: '提交失败,请刷新重试'
                });
            }
        });

    }

    render() {

        return (
            <div>
                <Modal title="重置密码" visible={this.state.visible}
                       onOk={this.handleOk.bind(this)} onCancel={this.handleCancel.bind(this)}>
                    <p>确定重置密码，并将新密码发到用户的邮箱么？</p>
                </Modal>
            </div>

        );
    }
}
