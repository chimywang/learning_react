/**
 * Created by qinmy on 16/3/11.
 */
import {Form, Radio, Modal} from 'antd';
import React, {Component} from 'react';
import MyTextInput from '../Common/MyTextInput';
import {get, post, put} from '../../helper/httpHelper';
import Config from '../Config/Config';
const FormItem = Form.Item;
const RadioGroup = Radio.Group;

export default class EditUserInfo extends Component {

    constructor() {
        super();
        this.state =
        {
            username: null,
            email: null,
            type: null,
            status: null,
            visible: false
        };
        this.id = '';
    }

    showModal(id, name, address, role, states) {

        console.log('223333id：' + id + '用户名：' + name + '邮箱：' + address + '角色：' + role + '状态：' + states);
        this.id = id;
        this.username = name;
        this.email = address;
        var juese = (role == '初级运营' ? '0' : (role == '高级运营' ? '1' : '2'));
        var zhuangtai = (states == '正常' ? 'true' : 'false');
        this.setState({
            username: name,
            email: address,
            type: juese,
            status: zhuangtai,
            visible: true
        });
        console.log('改完的角色：' + this.state.type + '改完的状态：' + this.state.status);
    }

    handleOk() {
        console.log('点击了确定');
        this.setState({
            username: this.refs.username.getValue(),
            email: this.refs.email.getValue(),
            visible: false
        });

        console.log('id' + this.id + '用户名' + this.userName + '邮箱' + this.address + '角色' + this.type + '状态' + this.state);
        this.executeEdit();
    }

    handleCancel(e) {
        console.log(e);
        this.setState({
            visible: false
        });
    }

    onChangeType(e) {
        console.log('radio checked', e.target.value);
        this.setState({
            username: this.refs.username.getValue(),
            email: this.refs.email.getValue(),
            type: e.target.value
        });
    }

    onChangeStates(e) {
        console.log('radio checked', e.target.value);
        this.setState({
            username: this.refs.username.getValue(),
            email: this.refs.email.getValue(),
            status: e.target.value
        });
    }

    executeEdit() {
        const self = this;
        console.log(' 传的参 ' + this.id + this.username + this.email + this.type + this.status);
        put({
            api: 'users/' + this.id,
            d: {username: this.state.username, email: this.state.email, userrole: this.state.type, is_active: this.state.status},
            s: x=> {
                self.setState({visible: false});
                self.props.editCallBack && self.props.editCallBack();
            },

            e: (m)=> {
                Modal.error({
                    title: '提示',
                    content: m
                });
            }
        });
    }

    render() {

        const formItemLayout = {
            labelCol: {span: 6},
            wrapperCol: {span: 14},
        };

        return (
            <div>
                <Modal title="编辑用户" visible={this.state.visible}
                       onOk={this.handleOk.bind(this)} onCancel={this.handleCancel.bind(this)}>
                    <Form horizontal>
                        <FormItem
                            {...formItemLayout}
                            label="用户：">
                            <MyTextInput defaultValue={this.state.username} ref="username"/>
                        </FormItem>
                        <FormItem
                            {...formItemLayout}
                            label="邮箱：">
                            <MyTextInput defaultValue={this.state.email} ref="email"/>
                        </FormItem>
                        <FormItem
                            {...formItemLayout}
                            label="角色：">
                            <RadioGroup value={this.state.type} onChange={this.onChangeType.bind(this)}>
                                <Radio value="0">初级运营</Radio>
                                <Radio value="1">高级运营</Radio>
                                <Radio value="2">管理员</Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem
                            {...formItemLayout}
                            label="状态：">
                            <RadioGroup value={this.state.status} onChange={this.onChangeStates.bind(this)}>
                                <Radio value="true">激活</Radio>
                                <Radio value="false">关闭</Radio>
                            </RadioGroup>
                        </FormItem>
                    </Form>
                </Modal>
            </div>

        );
    }
}
