/**
 * Created by David on 16/3/10.
 */
import React, {Component} from 'react';
import SearchBar from './SearchBar.js';
import ResultTable from './ResultTable.js';
import {getStream, get} from '../../helper/httpHelper';
import config from '../../config.js';
import {Modal} from 'antd';

export default class Statistics extends Component {

    constructor() {
        super();
        this.state = {
            loading: true,
            data: []
        };
    }

    doSearch(condition) {
        console.log('doSearch' + condition);
        this.statistics(condition);
    }

    doOutput(condition) {
        console.log('doOutput' + condition);
        this.outputStatistics(condition);
    }

    componentDidMount() {
        this.statistics({});
    }

    statistics(params) {
        const self = this;
        var p = JSON.stringify(params);
        get({
            api: 'statistic/' + p,
            //d: params,
            s: x=> {
                self.setState({
                    loading: false,
                    data: x.data
                });
            },

            e: (x)=> {
                self.setState({
                    loading: false,
                    data: []
                });
            }
        });
    }

    outputStatistics(params) {
        const self = this;
        var p = JSON.stringify(params);
        getStream({
            api: 'statistic/' + p,
            //d: params,
            s: x=> {
                self.setState({
                    loading: false,
                    data: x.data
                });},
            e: (x)=> {
                self.setState({
                    loading: false,
                    data: []
                });
                //Modal.error({
                //    title: '提示',
                //    content: x
                //});
            }
        });
    }

    render() {
        return (
            <div>
                <SearchBar ref="search" searchCallBack={this.doSearch.bind(this)} outPutCallBack={this.doOutput.bind(this)}/>
                <ResultTable data={this.state.data}/>
            </div>
        );
    }
}
