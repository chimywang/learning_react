/**
 * Created by David on 16/3/14.
 */
import React, {Component} from 'react';
import DateRangePicker from '../Common/DateRangePicker';
import './style.less';
import AutoComplete from '../Common/AutoComplete';
import config from '../../config.js';
import {Button, Radio, Input, Row, Col} from 'antd';

const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

export default class SearchBar extends Component
{
    constructor() {
        super();
        this.userName = '';
        //this.modelingTime = '';
        //this.articleTime = '';
        this.from_time = '';
        this.to_time = '';
        this.params = {};
    }

    componentWillMount() {

    }

    search() {

        if (config.user_Permission == 0) {
            //初级人员
            this.userName = config.user_id;
        } else {
            this.userName = this.refs.userNameInput.inputValue;
        }
        var p = {export_excel: '0',
            user_id: this.userName,
            date_from: this.from_time,
            date_to: this.to_time,
            sort_by: '',
            sort_direction: ''};
        this.props.searchCallBack && this.props.searchCallBack(p);
    }

    outPut() {
        if (config.user_Permission == 0) {
            //初级人员
            this.userName = config.user_id;
        } else {
            this.userName = this.refs.userNameInput.inputValue;
        }
        var p = {export_excel: '1',
            user_id: this.userName,
            date_from: this.from_time,
            date_to: this.to_time,
            sort_by: '',
            sort_direction: ''};
        this.props.outPutCallBack && this.props.outPutCallBack(p);
    }

    finishSelectModelingTime(state) {//自定义日期查询

        this.refs.radioGroup.setState({value: null});
        this.from_time = '';
        this.to_time = '';
        this.from_time = state.startValue;
        this.to_time = state.endValue;
    }

    finishSelectArticleTime(state) {
        this.articleTime = state.startValue + state.endValue;
    }

    onChange(e) {//全部, 近一月, 近三月
        console.log(`radio checked:${e.target.value}`);

        var myDate = new Date();
        this.to_time = new Date();
        if (e.target.value === 'all') {

            this.from_time = '';

        } else if (e.target.value === 'oneMonth') {
            myDate.setMonth(myDate.getMonth() - 1);
            this.from_time = myDate;

        } else if (e.target.value === 'threeMonth') {

            myDate.setMonth(myDate.getMonth() - 3);
            this.from_time = myDate;
        }
        this.refs.modelingTimeRange.clearTime();

    }

    render() {

        const titleLayout = {span: '2'};
        const nameLayout = {span: '5'};
        const radioLayout = {span: '5'};
        const timeLayout = {span: '7'};
        const exportResult = {marginLeft: '13px'};

        let dis = {
            disabled: false,
            placeholder: '姓名'
        };
        if (config.user_Permission == 0) {
            //初级人员
            dis = {
                disabled: true,
                placeholder: config.user_name,
            };
        }


        return (

            <div className="searchBar-container">

                <Row>
                    <Col className="title-label" {...titleLayout}>
                        <label>姓名:</label>
                    </Col>
                    <Col className="nameValue-label" {...nameLayout}>
                        <AutoComplete {...dis} ref="userNameInput" api="users/lists" method="post" fieldname="username" fieldvalue="id"/>
                    </Col>
                </Row>

                <Row style={{marginTop: '13px'}}>
                    <Col className="title-label" {...titleLayout}>
                        <label>统计时间:</label>
                    </Col>
                    <Col className="timeValue-label" {...radioLayout}>
                        <RadioGroup ref="radioGroup" onChange={this.onChange.bind(this)} defaultValue="all">
                            <RadioButton value="all" key="0">全部</RadioButton>
                            <RadioButton value="oneMonth" key="1">近一月</RadioButton>
                            <RadioButton value="threeMonth" key="2">近三月</RadioButton>
                        </RadioGroup>

                    </Col>
                    <Col {...timeLayout}>
                        <DateRangePicker ref="modelingTimeRange" showMiddle={true}
                                         pickerFinish={this.finishSelectModelingTime.bind(this)}/>
                    </Col>
                </Row>
                {/*
                 <Row style={{marginTop: '13px'}}>
                 <Col className="title-label" {...titleLayout}>
                 <label>文章发表时间:</label>
                 </Col>
                 <Col className="timeValue-label" {...timeLayout}>
                 <DateRangePicker ref="articleTimeRange" showMiddle = {true}
                 pickerFinish={this.finishSelectArticleTime.bind(this)} />
                 </Col>
                 </Row>
                 */}
                <Row style={{marginTop: '23px'}}>
                    <Col>
                        <Button type="primary" onClick={this.search.bind(this)}>搜索</Button>
                        <Button type="primary" onClick={this.outPut.bind(this)} style={exportResult}>导出结果</Button>
                    </Col>
                </Row>

            </div>
        );
    }
}
