/**
 * Created by David on 16/3/14.
 */
import React, {Component} from 'react';
import {Table} from 'antd';
import './style.less';

export default class ResultTable extends Component {

    constructor() {

        super();

        this.state = {
            data: [],
            pagination: {
                showQuickJumper: true,
                pageSize: 12
            },
            loading: false
        };

        this.columns = [{
            title: '用户名',
            dataIndex: 'username',
        }, {
            title: '建模文章数',
            dataIndex: 'article_modeling_count',
        }, {
            title: '判断不能建模',
            dataIndex: 'article_not_modeling_count',
        }, {
            title: '建模数量',
            dataIndex: 'model_create_count',
        }, {
            title: '已通过数量',
            dataIndex: 'model_pass_count',
        }, {
            title: '建模差错',
            dataIndex: 'model_correction_count',
        }, {
            title: '被删差错',
            dataIndex: 'model_delete_count',
        }, {
            title: '漏建差错',
            dataIndex: 'model_add_count',
        }, {
            title: '审核文章',
            dataIndex: 'audit_article_modeling_count',
        }, {
            title: '审核不能建模',
            dataIndex: 'audit_article_not_modeling_count',
        }, {
            title: '审核模型',
            dataIndex: 'audit_model_pass_count',
        }, {
            title: '审出建模差错',
            dataIndex: 'audit_model_correction_count',
        }, {
            title: '删除模型',
            dataIndex: 'audit_model_delete_count',
        }, {
            title: '增加模型',
            dataIndex: 'audit_model_add_count',
        }];
    }

    //componentWillMount() {
    //    const datas = [];
    //    for (let i = 0; i < 15; i++) {
    //        datas[i] = this.data;
    //    }
    //    this.setState({data: datas});
    //}

    render() {
        return (
            <div style={{marginTop: '13px'}}>
                <Table columns={this.columns}
                       dataSource={this.props.data}
                       loading={this.state.loading}
                       onChange={this.handleTableChange}
                       pagination={ this.pagination}
                />
            </div>
        );
    }
}
