/**
 * Created by chenjs on 16/3/11.
 */


import React, {Component} from 'react';
import {Row, Col, Button} from 'antd';
import './style.less';

export default class ActionBar extends Component {

    handleFinish() {
        this.props.onFinish && this.props.onFinish();
    }

    render() {

        const rowLayout = {type: 'flex', justify: 'space-around'};
        const colLayout = {span: '7'};
        const btnLayout = {style: {width: '100%'}, type: 'primary'};

        return (
            <div className="bar-container">
                <Row {...rowLayout}>
                    <Col {...colLayout}>
                        <Button {...btnLayout} onClick={this.props.newModel} disabled={this.props.readonly || !this.props.canNew}>新建模型</Button>
                    </Col>
                    <Col {...colLayout}>
                        <Button {...btnLayout} onClick={this.handleFinish.bind(this)} disabled={this.props.readonly || !this.props.canFinish}>完成</Button>
                    </Col>
                    <Col {...colLayout}>
                        <Button {...btnLayout} onClick={this.props.onNext} disabled={this.props.readonly || !this.props.canFinish}>完成,下一篇</Button>
                    </Col>
                </Row>
            </div>
        );
    }
}
