/**
 * Created by chenjs on 16/3/11.
 */

import React, {Component} from 'react';
import {Form, Row, Col, Button, Modal, Select} from 'antd';
import MyTextInput from '../Common/MyTextInput';
import Codemirror from 'react-codemirror';
import Markdown from 'react-remarkable';
import './style.less';
import 'codemirror/lib/codemirror.css';
import {put} from '../../helper/httpHelper';
import AutoComplete from '../Common/AutoComplete';
import DateHelper from '../../helper/dateHelper';
const FormItem = Form.Item;

export default class ArticleView extends Component {

    constructor() {
        super();
        this.state = {
            canEdit: false,
            code: ''
        };
        this.commiting = false;
        this.types = [{text: '预测型', value: '1'}, {text: '资讯型', value: '2'}];
        this.status = [{text: '正常', value: '1'}, {text: '隐藏', value: '2'}];
        this.auditStatus = [{text: '待判断', value: 1}, {text: '建模中', value: 2}, {text: '待审核', value: 3},
            {text: '审核中', value: 4}, {text: '已审核', value: 5}];
    }


    handleClick(type, e) {
        const self = this;
        e.preventDefault();
        switch (type) {
        case 'modify':
            this.setState({
                canEdit: true,
                code: this.state.article.content
            });
            break;
        case 'cancel':
            this.setState({
                canEdit: false,
                article: this.state.article
            });
            break;
        case 'submit':
            const params = {
                title: this.refs.title.getValue(),
                summary: this.refs.summary.getValue(),
                content: this.state.code,
                article_type: this.article_type,
                article_status: this.article_status,
                bigv_id: this.refs.bigv.getValue()[1]
            };
            put({
                api: 'articles/' + this.props.article.id,
                d: params,
                s: (x)=> {
                    Modal.success({
                        title: '提示',
                        content: '文章修改成功'
                    });
                    self.setState({
                        canEdit: !self.state.canEdit,
                        article: x.data
                    });
                },
                e: ()=> {
                    Modal.error({
                        title: '提示',
                        content: '文章修改失败,请重新提交'
                    });
                }
            });
            break;
        default:
            break;
        }
    }

    handleCodeChange(code) {
        this.setState({
            code: code
        });
    }

    componentWillMount() {
        const p = this.props;
        if (p.article) {
            this.setState({
                article: p.article,
            });
            this.article_type = p.article_type;
            this.article_status = p.article_status;
        }
    }

    componentWillReceiveProps(p) {
        if (p.article) {
            this.setState({
                article: p.article,
            });
            this.article_type = p.article_type;
            this.article_status = p.article_status;
        }
    }

    handleSelect(name, value) {
        switch (name) {
        case 'article_type':
            this.article_type = value;
            break;
        case 'article_status':
            this.article_status = value;
            break;
        default:
            break;
        }
    }

    handleBackToList() {
        this.props.showList && this.props.showList();
    }

    render() {
        const formItemLayout = {
            labelCol: {span: 2},
            wrapperCol: {span: 21},
            style: {
                marginBottom: '0px'
            }
        };

        const span1Layout = {
            labelCol: {span: 6},
            wrapperCol: {span: 18}
        };

        const spanLayout = {
            labelCol: {span: 10},
            wrapperCol: {span: 14}
        };

        let approval_status = '';
        let article_type = '';
        let article_status = '';

        if (this.state.article) {
            this.auditStatus.forEach(x=> {
                if (x.value == this.state.article.approval_status) {
                    approval_status = x.text;
                }
            });

            this.types.forEach(x=> {
                if (x.value == this.state.article.article_type) {
                    article_type = x.text;
                }
            });

            this.status.forEach(x=> {
                if (x.value == this.state.article.article_status) {
                    article_status = x.text;
                }
            });
        }

        return (
            <div className="av_container">
                {
                    this.props.showBack ? (
                        <Row>
                            <Col span="2" className="back" onClick={this.handleBackToList.bind(this)}><a href="#">返回列表</a></Col>
                        </Row>
                    ) : ''
                }
                <Form horizontal onSubmit={this.handleClick.bind(this)}>
                    <FormItem ref="test"
                        {...formItemLayout}
                              label="标题：">
                        {
                            this.state.canEdit ? <MyTextInput ref="title" defaultValue={this.state.article ? this.state.article.title : ''}/> :
                                <MyTextInput unableedit defaultValue={this.state.article ? this.state.article.title : ''}/>
                        }
                    </FormItem>
                    <FormItem
                        {...formItemLayout}
                        label="摘要：">
                        {
                            this.state.canEdit ? <MyTextInput ref="summary" textarea defaultValue={this.state.article ? this.state.article.summary : ''}/> :
                                <MyTextInput unableedit defaultValue={this.state.article ? this.state.article.summary : ''}/>
                        }
                    </FormItem>
                    <FormItem className="content"
                        {...formItemLayout}
                              label="正文：">
                        {
                            this.state.canEdit ?
                                <div>
                                    <Codemirror ref="editor" value={this.state.code}
                                                onChange={this.handleCodeChange.bind(this)}/>
                                </div> :
                                <Markdown source={this.state.article ? this.state.article.content : ''}/>
                        }
                    </FormItem>
                    <Row className="av-form-row av-row-no-bottom">
                        <Col span="6" offset="2">
                            <FormItem
                                {...span1Layout}
                                label="大V：">
                                {
                                    this.state.canEdit ?
                                        <AutoComplete ref="bigv"
                                                      defaultValue={this.state.article && this.state.article.big ? [this.state.article.big.realname, this.state.article.big.id] : ['', '']}
                                                      api="bigvs/hint/"
                                                      fieldname="realname"
                                                      fieldvalue="id"/> :
                                        <span
                                            className="ant-form-text">{this.state.article && this.state.article.big ? this.state.article.big.realname : ''}</span>
                                }
                            </FormItem>
                        </Col>
                        <Col span="5">
                            <FormItem
                                {...spanLayout}
                                label="类型：">
                                {
                                    this.state.canEdit ?
                                        <Select placeholder={this.types.placeholder} defaultValue={this.state.article ? this.state.article.article_type : ''}
                                                onSelect={this.handleSelect.bind(this, 'article_type')}>
                                            {
                                                this.types.map(x=> {
                                                    return <Option value={x.value}>{x.text}</Option>;
                                                })
                                            }
                                        </Select> :
                                        <p className="ant-form-text">{article_type}</p>
                                }
                            </FormItem>
                        </Col>
                        <Col span="5">
                            <FormItem
                                labelCol={{span: 12}}
                                wrapperCol={{span: 12}}
                                label="文章状态：">
                                {
                                    this.state.canEdit ?
                                        <Select placeholder={this.status.placeholder} defaultValue={this.state.article ? this.state.article.article_status : ''}
                                                onSelect={this.handleSelect.bind(this, 'article_status')}>
                                            {
                                                this.status.map(x=> {
                                                    return <Option value={x.value}>{x.text}</Option>;
                                                })
                                            }
                                        </Select> :
                                        <p className="ant-form-text">{article_status}</p>
                                }
                            </FormItem>
                        </Col>
                        <Col span="6">
                            <FormItem
                                labelCol={{span: 6}}
                                wrapperCol={{span: 18}}
                                label="来源：">
                                <div>
                                    {
                                        this.state.article && this.state.article.href ?
                                            <a target="_blank" className="ant-form-text" href={this.state.article ? this.state.article.href : ''}>链接</a> : ''
                                    }
                                </div>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row className="av-form-row">
                        <Col span="5" offset="2">
                            <FormItem
                                labelCol={{span: 12}}
                                wrapperCol={{span: 12}}
                                label="建模状态：">
                                <span className="ant-form-text">{approval_status}</span>
                            </FormItem>
                        </Col>
                        <Col span="7">
                            <FormItem
                                labelCol={{span: 10}}
                                wrapperCol={{span: 14}}
                                label="发布日期：">
                                <span className="ant-form-text">{this.state.article ? DateHelper.formatDate(this.state.article.publish_on) : ''}</span>
                            </FormItem>
                        </Col>
                        <Col span="10">
                            <FormItem
                                labelCol={{span: 4}}
                                wrapperCol={{span: 20}}
                                label="更新：">
                                <p className="ant-form-text">{this.state.article && this.state.article.creator ? (this.state.article.creator.username + ' ' +
                                (this.state.article.article_edited_on ? DateHelper.formatDate(this.state.article.article_edited_on, 'yyyy-MM-dd HH:mm:ss') : '')) : ''}</p>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        {
                            this.state.canEdit ? [
                                <Col span="6" offset="5">
                                    <Button type="primary" htmlType="submit" style={{width: '100%'}} disabled={this.props.readonly}
                                            onClick={this.handleClick.bind(this, 'cancel')}>取消</Button>
                                </Col>,
                                <Col span="6" offset="2">
                                    <Button type="primary" htmlType="submit" style={{width: '100%'}} disabled={this.props.readonly}
                                            onClick={this.handleClick.bind(this, 'submit')}>提交</Button>
                                </Col>
                            ] :
                                (<Col span="6" offset="9">
                                    <Button type="primary" htmlType="submit" style={{width: '100%'}} disabled={this.props.readonly}
                                            onClick={this.handleClick.bind(this, 'modify')}>修改</Button>
                                </Col>)
                        }
                    </Row>
                </Form>
            </div>
        );
    }
}
