/**
 * Created by chenjs on 16/3/11.
 */

import React, {Component} from 'react';
import {Form, Radio, Input, Select, Col, DatePicker, Button, Row, Modal, Spin} from 'antd';
import './style.less';
import MyTextInput from '../Common/MyTextInput';
import {post, delet, put} from '../../helper/httpHelper';
import DateHelper from '../../helper/dateHelper';
import config from '../../config.js';
import AutoComplete from '../Common/AutoComplete';
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;
const confirm = Modal.confirm;

export default class ModelItem extends Component {

    constructor() {
        super();
        this.state =
        {
            loading: false,
            role: '1',
            editMode: true,
            data: {
                id: '',
                relative_object_id: '',
                forecast_date_from: '',
                forecast_date_to: '',
                forecast_direction: '',
                forecast_point: '',
                validate_date: '',
                forecast_text: '',
                model_type: 'DL',
                updated_by: '',
                updated_on: '',
            }
        };
    }

    componentWillMount() {
        if (this.props.data) {
            if (config.user_Permission == 1 && this.props.data.model_status == 'DS') {
                this.setState({
                    data: this.props.data,
                    editMode: true
                });
            } else if (config.user_Permission == 0 && this.props.data.model_status == 'XT') {
                this.setState({
                    data: this.props.data,
                    editMode: true
                });
            } else {
                this.setState({
                    data: this.props.data,
                    editMode: false
                });
            }
        }
    }

    componentWillReceiveProps(p) {
        if (p.data) {
            if (config.user_Permission == 1 && p.data.model_status == 'DS') {
                this.setState({
                    data: p.data,
                    editMode: true
                });
            } else {
                this.setState({
                    data: p.data,
                    editMode: false
                });
            }
        }
    }

    handleCommit() {
        const params = this.generateParam();
        const self = this;
        self.setState({
            loading: true
        });
        if (this.state.data.id) {
            put({
                api: 'models/' + this.state.data.id,
                d: params,
                s: (x)=> {
                    self.setState({
                        loading: false,
                        editMode: false,
                        data: x.data
                    });
                    this.props.onReady && this.props.onReady(this.props.index, true, x.data);
                    Modal.success({
                        title: '提示',
                        content: '模型修改成功'
                    });
                },
                e: (m)=> {
                    self.setState({
                        loading: false
                    });
                    Modal.error({
                        title: '提示',
                        content: m || '模型修改失败'
                    });
                }
            });
        } else {
            post({
                api: 'models',
                d: params,
                s: (x)=> {
                    self.setState({
                        loading: false,
                        editMode: false,
                        data: x.data
                    });
                    this.props.onReady && this.props.onReady(this.props.index, true, x.data);
                    Modal.success({
                        title: '提示',
                        content: '模型创建成功'
                    });
                },
                e: (m)=> {
                    self.setState({
                        loading: false
                    });
                    Modal.error({
                        title: '提示',
                        content: m || '模型创建失败'
                    });
                }
            });
        }
    }

    generateParam() {
        const params = {};
        params.article_id = this.props.articleId;
        params.forecast_text = this.refs.forecast_text.getValue();
        params.validate_date = this.state.data.validate_date;
        params.model_type = this.state.data.model_type;
        switch (this.state.data.model_type) {
        case 'DL':
            params.forecast_date_from = this.state.data.forecast_date_from;
            params.forecast_date_to = this.state.data.forecast_date_to;
            params.relative_object_id = this.refs.relative_object.getValue()[1];
            if (this.state.data.forecast_direction) {
                params.forecast_direction = this.state.data.forecast_direction;
                if (this.state.data.forecast_direction == '4') {
                    params.forecast_point_from = this.refs.forecast_point_from.getValue();
                    params.forecast_point_to = this.refs.forecast_point_to.getValue();
                } else {
                    params.forecast_point = this.refs.forecast_point.getValue();
                }
            }
            break;
        case 'DX':
            params.forecast_date_from = this.state.data.forecast_date_from;
            params.forecast_date_to = this.state.data.forecast_date_to;
            params.relative_object_id = this.refs.relative_object.getValue()[1];
            params.forecast_direction = this.state.data.forecast_direction;
            params.forecast_point = this.refs.forecast_point.getValue();
            params.reference_type = this.state.data.reference_type;
            break;
        case 'MS':
            break;
        default:
            break;
        }
        return params;
    }

    handleModify() {
        this.setState({editMode: true});
        this.props.onReady && this.props.onReady(this.props.index, false, this.state.data);
    }

    handleTypeChange(e) {
        this.state.data.model_type = e.target.value;
        this.setState({data: this.state.data});
    }

    handleValidateDate(date) {
        this.state.data.validate_date = date;
    }

    handleForecastRange(value) {
        this.state.data.forecast_date_from = value[0];
        this.state.data.forecast_date_to = value[1];
    }

    handleDirectChange(value) {
        this.state.data.forecast_direction = value;
        this.setState(this.state);
    }

    handleRefChange(value) {
        this.state.data.reference_type = value;
    }

    handleDelete() {
        const self = this;
        confirm({
            title: '提示',
            content: '您是否确认删除该模型',
            onOk() {
                self.setState({
                    loading: true
                });
                if (self.state.data.id) {
                    delet({
                        api: 'models/' + self.state.data.id,
                        s: ()=> {
                            self.setState({
                                loading: false,
                                editMode: false,
                            });
                            self.props.onDelete && self.props.onDelete(self.props.index);
                            Modal.success({
                                title: '提示',
                                content: '模型删除成功'
                            });
                        },
                        e: (m)=> {
                            self.setState({
                                loading: false
                            });
                            Modal.error({
                                title: '提示',
                                content: m || '模型删除失败'
                            });
                        }
                    });
                } else {
                    self.props.onDelete && self.props.onDelete(self.props.index);
                }
            },
            onCancel() {
            }
        });
    }

    handlePass() {
        const self = this;
        self.setState({
            loading: true
        });
        put({
            api: 'models/' + this.state.data.id + '/pass',
            s: ()=> {
                self.setState({
                    loading: false,
                    editMode: false
                });
                this.props.onReady && this.props.onReady(this.props.index, false);
                Modal.success({
                    title: '提示',
                    content: '审核通过成功'
                });
            },
            e: (m)=> {
                self.setState({
                    loading: false
                });
                Modal.error({
                    title: '提示',
                    content: m || '审核通过失败'
                });
            }
        });
    }

    handleCorrection() {
        const params = this.generateParam();
        const self = this;
        self.setState({
            loading: true
        });
        put({
            api: 'models/' + this.state.data.id + '/correction',
            d: params,
            s: (x)=> {
                self.setState({
                    loading: false,
                    editMode: false,
                    data: x.data
                });
                this.props.onReady && this.props.onReady(this.props.index, false);
                Modal.success({
                    title: '提示',
                    content: '差错通过成功'
                });
            },
            e: (m)=> {
                self.setState({
                    loading: false
                });
                Modal.error({
                    title: '提示',
                    content: m || '差错通过失败'
                });
            }
        });
    }

    render() {
        const formItemLayout = {
            labelCol: {span: 5},
            wrapperCol: {span: 18}
        };

        const btnLayout = {style: {width: '100%'}, type: 'primary'};

        let btnRow;
        const c = config;
        if (c.user_Permission == 0 || (this.state.data && this.state.data.model_status == 'YS')) {
            btnRow = (
                <Row type="flex" justify="space-around">
                    <Col span="7">
                        {
                            this.state.editMode ?
                                <Button {...btnLayout} onClick={this.handleCommit.bind(this)} disabled={this.props.readonly}>提交</Button> :
                                <Button {...btnLayout} onClick={this.handleModify.bind(this)} disabled={this.props.readonly}>修改</Button>
                        }
                    </Col>
                    <Col span="7">
                        <Button {...btnLayout} onClick={this.handleDelete.bind(this)} disabled={this.props.readonly}>删除</Button>
                    </Col>
                </Row>
            );
        } else {
            btnRow = (
                <Row type="flex" justify="space-around">
                    <Col span="7">
                        <Button {...btnLayout} onClick={this.handlePass.bind(this)} disabled={this.props.readonly}>审核通过</Button>
                    </Col>
                    <Col span="7">
                        <Button {...btnLayout} onClick={this.handleCorrection.bind(this)} disabled={this.props.readonly}>差错通过</Button>
                    </Col>
                    <Col span="7">
                        <Button {...btnLayout} onClick={this.handleDelete.bind(this)} disabled={this.props.readonly}>删除</Button>
                    </Col>
                </Row>
            );
        }

        let components = [];
        switch (this.state.data.model_type) {
        case 'dl':
        case 'DL':
            components = [
                <FormItem
                    {...formItemLayout}
                    label="预测周期：" required>
                    <RangePicker style={{width: '100%'}} disabled={!this.state.editMode} onChange={this.handleForecastRange.bind(this)}
                                 defaultValue={[this.state.data.forecast_date_from, this.state.data.forecast_date_to]}/>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="相关标的：" required>
                    <AutoComplete ref="relative_object" defaultValue={this.state.data.object ? [this.state.data.object.name, this.state.data.object.id] : ['', '']}
                                  disabled={!this.state.editMode}
                                  api="models/object/"
                                  fieldname="name"
                                  fieldvalue="id"/>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="预期点位：" required>
                    <Col span="6">
                        <Select defaultValue={this.state.data.forecast_direction} disabled={!this.state.editMode} onChange={this.handleDirectChange.bind(this)}>
                            <Option value="1">大于</Option>
                            <Option value="2">小于</Option>
                            <Option value="3">约等于</Option>
                            <Option value="4">介于</Option>
                        </Select>
                    </Col>
                    <Col span="1">&nbsp;</Col>
                    {
                        this.state.data.forecast_direction == '4' ? ([
                            <Col span="8">
                                <MyTextInput ref="forecast_point_from" defaultValue={this.state.data.forecast_point_from} disabled={!this.state.editMode}/>
                            </Col>,
                            <Col span="1">至</Col>,
                            <Col span="8">
                                <MyTextInput ref="forecast_point_to" defaultValue={this.state.data.forecast_point_to} disabled={!this.state.editMode}/>
                            </Col>
                        ]) : (
                            <Col span="17">
                                <MyTextInput ref="forecast_point" defaultValue={this.state.data.forecast_point} disabled={!this.state.editMode}/>
                            </Col>
                        )
                    }
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="验证日：" required>
                    <DatePicker onChange={this.handleValidateDate.bind(this)} size="small" defaultValue={this.state.data.validate_date}
                                disabled={!this.state.editMode}/>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="验证观点：">
                    <MyTextInput textarea ref="forecast_text" defaultValue={this.state.data.forecast_text} disabled={!this.state.editMode}/>
                </FormItem>
            ];
            break;
        case 'dx':
        case 'DX':
            components = [
                <FormItem
                    {...formItemLayout}
                    label="预测周期：" required>
                    <RangePicker style={{width: '100%'}} size="small" disabled={!this.state.editMode} onChange={this.handleForecastRange.bind(this)}
                                 defaultValue={[this.state.data.forecast_date_from, this.state.data.forecast_date_to]}/>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="相关标的：" required>
                    <AutoComplete ref="relative_object" defaultValue={this.state.data.object ? [this.state.data.object.name, this.state.data.object.id] : ['', '']}
                                  disabled={!this.state.editMode}
                                  api="models/object/"
                                  fieldname="name"
                                  fieldvalue="id"/>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="预期方向：" required>
                    <Col span="7">
                        <Select defaultValue={this.state.data.reference_type} disabled={!this.state.editMode} onChange={this.handleRefChange.bind(this)}>
                            <Option value="JD">绝对数值</Option>
                            <Option value="XD">相对基准</Option>
                        </Select>
                    </Col>
                    <Col span="1">
                        &nbsp;
                    </Col>
                    <Col span="7">
                        <Select defaultValue="1" disabled={!this.state.editMode} onChange={this.handleDirectChange.bind(this)}
                                defaultValue={this.state.data.forecast_direction}>
                            <Option value="1">大涨</Option>
                            <Option value="2">小涨</Option>
                            <Option value="3">震荡</Option>
                            <Option value="4">小跌</Option>
                            <Option value="5">大跌</Option>
                        </Select>
                    </Col>
                    <Col span="1">
                        &nbsp;
                    </Col>
                    <Col span="7">
                        <MyTextInput ref="forecast_point" defaultValue={this.state.data.forecast_point} disabled={!this.state.editMode}/>
                    </Col>
                    <Col span="1">
                        %
                    </Col>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="验证日：" required>
                    <DatePicker onChange={this.handleValidateDate.bind(this)} size="small" defaultValue={this.state.data.validate_date}
                                disabled={!this.state.editMode}/>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="验证观点：">
                    <MyTextInput textarea ref="forecast_text" defaultValue={this.state.data.forecast_text} disabled={!this.state.editMode}/>
                </FormItem>
            ];
            break;
        default:
            components = [
                <FormItem
                    {...formItemLayout}
                    label="验证日：" required>
                    <DatePicker onChange={this.handleValidateDate.bind(this)} size="small" defaultValue={this.state.data.validate_date}
                                disabled={!this.state.editMode}/>
                </FormItem>,
                <FormItem
                    {...formItemLayout}
                    label="验证观点：" required>
                    <MyTextInput textarea ref="forecast_text" defaultValue={this.state.data.forecast_text} disabled={!this.state.editMode}/>
                </FormItem>
            ];
            break;
        }

        return (
            <Spin spining={this.state.loading}>
                <div className="model-container">
                    <Form horizontal className="form-container">
                        <FormItem
                            {...formItemLayout}
                            label="建模类型：">
                            <RadioGroup defaultValue={this.state.data.model_type} onChange={this.handleTypeChange.bind(this)} disabled={!this.state.editMode}>
                                <Radio key="a" value="DL">定量型</Radio>
                                <Radio key="b" value="DX">定性型</Radio>
                                <Radio key="c" value="MS">描述型</Radio>
                            </RadioGroup>
                        </FormItem>
                        {components}
                        <FormItem
                            {...formItemLayout}
                            label="状态：">
                            <p className="ant-form-text">{this.state.data.model_status == 'DS' ? '待审核' : (this.state.data.model_status == 'YS' ? '已审核' : '')}</p>
                        </FormItem>
                        <FormItem
                            {...formItemLayout}
                            label="建模人：">
                            <p className="ant-form-text">
                                {
                                    this.state.data.id ?
                                        ((this.state.data.creator ? this.state.data.creator.username : '') + ' ' + (this.state.data.updated_on ? DateHelper.formatDate(this.state.data.updated_on, 'yyyy-MM-dd HH:mm:ss') : '')) :
                                        config.user_name
                                }</p>
                        </FormItem>
                        {btnRow}
                    </Form>
                </div>
            </Spin>
        );
    }
}
