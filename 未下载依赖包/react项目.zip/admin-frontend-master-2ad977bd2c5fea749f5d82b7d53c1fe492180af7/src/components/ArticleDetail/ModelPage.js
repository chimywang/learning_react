/**
 * Created by chenjs on 16/3/11.
 */

import React, {Component} from 'react';
import EnableModuleView from './EnableModuleView';
import ActionBar from './ActionBar';
import ModelItem from './ModelItem';
import './style.less';
import {Modal} from 'antd';
import {get, post} from '../../helper/httpHelper';

export default class ModelPage extends Component {
    constructor() {
        super();
        this.state = {
            canModeling: 0,
            modelList: []
        };
    }

    componentWillMount() {
        if (this.props.article) {
            this.state.canModeling = this.props.article.can_modeling;
            this.state.modelList = this.props.article.article_models.map(x=> {
                if (x.model_status == 'XT') {
                    return {
                        ready: false,
                        data: x
                    };
                } else {
                    return {
                        ready: true,
                        data: x
                    };
                }
            });
            this.setState(this.state);
        }
    }

    componentWillReceiveProps(p) {
        if (p.article) {
            this.state.canModeling = p.article.can_modeling;
            this.state.modelList = p.article.article_models.map(x=> {
                if (x.model_status == 'XT') {
                    return {
                        ready: false,
                        data: x
                    };
                } else {
                    return {
                        ready: true,
                        data: x
                    };
                }
            });
            this.setState(this.state);
        }
    }

    handleNewModel() {
        this.state.modelList.push({ready: false, data: null});
        this.setState(this.state);
    }

    handleCanModeling(value) {
        this.setState({
            canModeling: value
        });
    }

    handleReadyChange(index, status, model) {
        this.state.modelList[index].ready = status;
        this.state.modelList[index].data = model;
        this.setState(this.state);
    }

    handleDelete(index) {
        this.state.modelList.splice(index, 1);
        this.setState(this.state);
    }

    handleFinish() {
        if (this.state.canModeling == 0) {
            Modal.success({
                title: '提示',
                content: '请设置能否建模'
            });
        } else {
            get({
                api: 'articles/' + this.props.article.id + '/can_finish',
                s: ()=> {
                    this.props.showList && this.props.showList();
                },
                e: x=> {
                    Modal.error({
                        title: '提示',
                        content: x
                    });
                }
            });
        }
    }

    handleNext() {
        if (this.state.canModeling == 0) {
            Modal.success({
                title: '提示',
                content: '请设置能否建模'
            });
        } else {
            get({
                api: 'articles/' + this.props.article.id + '/can_finish',
                s: ()=> {
                    post({
                        api: 'articles/' + this.props.article.id + '/next',
                        s: (x)=> {
                            this.props.showDetail && this.props.showDetail(x.data);
                        },
                        e: (m)=> {
                            Modal.error({
                                title: '提示',
                                content: m || '获取下一篇失败'
                            });
                        }
                    });
                },
                e: x=> {
                    Modal.error({
                        title: '提示',
                        content: x
                    });
                }
            });
        }
    }

    render() {
        const modelList = [];
        for (let i = 0; i < this.state.modelList.length; i++) {
            const x = this.state.modelList[i];
            modelList.push(x.data ?
                <ModelItem key={x.data.id} data={x.data} index={i} onReady={this.handleReadyChange.bind(this)} {...this.props} onDelete={this.handleDelete.bind(this)}
                           articleId={this.props.article.id}/> :
                <ModelItem index={i} onReady={this.handleReadyChange.bind(this)} onDelete={this.handleDelete.bind(this)}
                           articleId={this.props.article.id}/>);
        }

        const actionParam = {};
        if (this.state.canModeling == 0) {
            actionParam.disablenew = true;
            actionParam.disablefinish = true;
            actionParam.disablenext = true;
        }

        let canFinish = true;
        let canNew = true;
        if (this.state.canModeling == '1') {
            if (this.state.modelList.length == 0) {
                canFinish = false;
            } else if (this.state.modelList.some(x=> !x.ready)) {
                canFinish = false;
            }
        } else if (this.state.canModeling == '2') {
            canNew = false;
        } else {
            canNew = false;
            canFinish = false;
        }

        return (
            <div>
                <EnableModuleView changeCallBack={this.handleCanModeling.bind(this)} {...this.props}/>
                <div className="models-container">
                    {this.state.canModeling == 1 ? modelList : ''}
                </div>
                <ActionBar newModel={this.handleNewModel.bind(this)} {...this.props} canFinish={canFinish} canNew={canNew}
                           onFinish={this.handleFinish.bind(this)} onNext={this.handleNext.bind(this)}/>
            </div>
        );
    }
}
