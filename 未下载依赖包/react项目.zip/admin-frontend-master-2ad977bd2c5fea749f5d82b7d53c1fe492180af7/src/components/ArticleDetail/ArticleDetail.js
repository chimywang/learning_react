/**
 * Created by chenjs on 16/3/11.
 */

import React, {Component} from 'react';
import ArticleView from './ArticleView';
import ModelPage from './ModelPage';
import {Row, Col} from 'antd';
import './style.less';
import config from '../../config.js';

export default class ArticleDetail extends Component {
    render() {
        let articleReadOnly = false;
        let modelReadOnly = false;
        let showBack = false;
        if ((config.user_Permission == 0 && this.props.article.approval_status > 2) ||
            (config.user_Permission == 1 && this.props.article.approval_status < 3)) {
            articleReadOnly = true;
            modelReadOnly = true;
            showBack = true;
        }

        if (config.user_Permission == 2) {
            articleReadOnly = false;
            modelReadOnly = true;
            showBack = true;
        }
        return (
            <div>
                <Row>
                    <Col span="14">
                        <ArticleView showBack={showBack} readonly={articleReadOnly} {...this.props}/>
                    </Col>
                    <Col span="10">
                        <ModelPage readonly={modelReadOnly} {...this.props}/>
                    </Col>
                </Row>
            </div>
        );
    }
}
