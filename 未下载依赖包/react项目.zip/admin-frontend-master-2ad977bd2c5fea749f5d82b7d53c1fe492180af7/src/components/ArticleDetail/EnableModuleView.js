/**
 * Created by chenjs on 16/3/11.
 */

import React, {Component} from 'react';
import {Form, Button, Radio, Modal, Spin} from 'antd';
import './style.less';
import {get} from '../../helper/httpHelper';
import DateHelper from '../../helper/dateHelper';
const FormItem = Form.Item;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

export default class EnableModuleView extends Component {

    constructor() {
        super();
    }

    handleChange(e) {
        const self = this;
        if (e.target.value === '1') {
            get({
                api: 'articles/' + this.props.article.id + '/can_modeling',
                s: ()=> {
                    Modal.success({
                        title: '提示',
                        content: '建模状态修改成功'
                    });
                    this.props.changeCallBack && this.props.changeCallBack(e.target.value);
                },
                e: (m)=> {
                    Modal.error({
                        title: '提示',
                        content: m || '建模状态修改失败'
                    });
                }
            });
        } else {
            get({
                api: 'articles/' + this.props.article.id + '/cannot_modeling',
                s: ()=> {
                    Modal.success({
                        title: '提示',
                        content: '建模状态修改成功'
                    });
                    this.props.changeCallBack && this.props.changeCallBack(e.target.value);
                },
                e: (m)=> {
                    Modal.error({
                        title: '提示',
                        content: m || '建模状态修改失败'
                    });
                }
            });
        }
    }

    render() {
        const formItemLayout = {
            labelCol: {span: 5},
            wrapperCol: {span: 18},
        };

        const marginStyle = {marginLeft: '20px'};
        return (
            <Form horizontal className="emv-container">
                <FormItem
                    {...formItemLayout}
                    label="能否建模:">
                    {
                        this.props.readonly ?
                            (this.props.article.can_modeling == 1 ? <span style={marginStyle}>能够</span> : <span style={marginStyle}>不能</span>) :
                            (<RadioGroup defaultValue={this.props.article.can_modeling + ''} size="default" style={marginStyle}
                                         onChange={this.handleChange.bind(this)}>
                                <RadioButton value="1">能够</RadioButton>
                                <RadioButton value="2">不能</RadioButton>
                            </RadioGroup>)
                    }
                </FormItem>
                <FormItem
                    {...formItemLayout}
                    label="更新:">
                    <span
                        style={marginStyle}>{(this.props.article.can_modeling_by || '') + ' ' +
                    (this.props.article.can_modeling_on ? DateHelper.formatDate(this.props.article.can_modeling_on, 'yyyy-MM-dd HH:mm:ss') : '')}</span>
                </FormItem>
            </Form>
        );
    }
}
