/**
 * Created by chenjs on 16/3/9.
 */

import React, {Component} from 'react';
import './style.less';
import {Modal} from 'antd';
import {get, post} from '../../helper/httpHelper';
import config from '../../config';

export default class Header extends Component {

    showConfirm() {
        const confirm = Modal.confirm;
        const self = this;
        confirm({
            title: '您是否确认要退出当前用户',
            content: '点确认退出登录',
            onOk() {
                self.handleOut();
            },
            onCancel() {
            }
        });
    }

    handleOut() {
        const self = this;
        get({
            api: 'signout',

            s: ()=> {
                self.props.outCallBack && self.props.outCallBack();
            },
            e: x=> {
                Modal.error({
                    title: '提示',
                    content: x
                });
            }
        });
    }

    render() {
        return (
            <div className="header-container">
                <div className="content">
                    <span className="title">人工建模管理端</span>
                    <span className="logout" onClick={this.showConfirm.bind(this)}>{this.props.outButton}</span>
                    <span className="devider"/>
                    <span className="welcome">{this.props.userName}</span>
                </div>
            </div>
        );
    }
}
