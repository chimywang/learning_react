/**
 * Created by chenjs on 16/3/10.
 */

import React, {Component} from 'react';
import ArticlePage from '../ArticlePage/ArticlePage';
import Config from '../Config/Config';
import Statistics from '../Statistics/Statistics';
import './style.less';
import {Tabs} from 'antd';
import config from '../../config';
const TabPane = Tabs.TabPane;

export default class MainPage extends Component {

    constructor() {
        super();
        this.state = {
            showList: false
        };
    }

    handleTab(key) {
        if (key == '1') {
            this.setState({
                showList: true
            });
        }
    }

    render() {
        const c = config;
        return (
            <div className="tab-container">
                {
                    c.user_Permission != 2 ?
                        <Tabs defaultActiveKey="1">
                            <TabPane tab="全部文章" key="1">
                                <ArticlePage />
                            </TabPane>
                            <TabPane tab="不能建模" key="2">
                                <ArticlePage disableModel/>
                            </TabPane>
                            <TabPane tab="数据统计" key="3">
                                <Statistics />
                            </TabPane>
                        </Tabs> :
                        <Tabs defaultActiveKey="1" onChange={this.handleTab.bind(this)}>
                            <TabPane tab="全部文章" key="1">
                                <ArticlePage showList={this.state.showList ? this.state.showList : false}/>
                            </TabPane>
                            <TabPane tab="不能建模" key="2">
                                <ArticlePage disableModel/>
                            </TabPane>
                            <TabPane tab="数据统计" key="3">
                                <Statistics />
                            </TabPane>
                            <TabPane tab="设置" key="4">
                                <Config />
                            </TabPane>
                        </Tabs>
                }
            </div>
        );
    }
}
