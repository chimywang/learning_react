/**
 * Created by chenjs on 16/3/10.
 */

import React, {Component} from 'react';
import {Select, Button, Row, Col} from 'antd';
import AutoComplete from '../Common/AutoComplete';
import DateRangePicker from '../Common/DateRangePicker';
import './style.less';

export default class SearchBar extends Component {

    constructor() {
        super();
        this.types = {placeholder: '类型', data: [{text: '全部', value: '-1'}, {text: '预测型', value: '1'}, {text: '资讯型', value: '2'}]};
        this.status = {placeholder: '状态', data: [{text: '全部', value: '-1'}, {text: '正常', value: '1'}, {text: '隐藏', value: '2'}]};
        this.enableModel = {
            placeholder: '能否建模',
            data: [{text: '全部', value: '-1'}, {text: '能够', value: '1'}, {text: '不能', value: '2'}]
        };
        this.auditStatus = {
            placeholder: '审核状态',
            data: [{text: '全部', value: '-1'}, {text: '待判断', value: 1}, {text: '建模中', value: 2}, {text: '待审核', value: 3},
                {text: '审核中', value: 4}, {text: '已审核', value: 5}]
        };
        this.diff = {placeholder: '差错', data: [{text: '全部', value: '-1'}, {text: '有', value: 1}, {text: '无', value: 2}]};
        this.params = {};
    }

    handleSearch() {
        if (this.refs.title.getValue().length > 0) {
            this.params.title = this.refs.title.getValue()[0];
        }
        if (this.refs.bigv.getValue()[1]) {
            this.params.bigv_id = this.refs.bigv.getValue()[1];
        } else {
            this.params.big_name = this.refs.bigv.getValue()[0];
        }
        if (this.refs.modeler.getValue()[1]) {
            this.params.model_creator_id = this.refs.modeler.getValue()[1];
        } else {
            this.params.model_creator_name = this.refs.modeler.getValue()[0];
        }
        if (this.refs.auditor.getValue()[1]) {
            this.params.model_auditor_id = this.refs.auditor.getValue()[1];
        } else {
            this.params.model_auditor_name = this.refs.auditor.getValue()[0];
        }
        this.params.article_created_befor = this.refs.datePicker.getValue().start;
        this.params.article_created_after = this.refs.datePicker.getValue().end;
        this.props.callBack && this.props.callBack(this.params);
    }

    handleSelect(name, value) {
        if (value != '-1') {
            this.params[name] = value;
        } else {
            this.params[name] = '';
        }
    }

    componentDidMount() {
        if (this.props.disableModel) {
            this.params.can_modeling = 2;
        }
    }


    render() {
        const style = {width: '100%'};
        return (
            <div>
                <Row type="flex" justify="space-around">
                    <Col span="6">
                        <AutoComplete ref="title" placeholder="标题" style={style} api="topics/hint/" fieldname="title" fieldvalue="title"/>
                    </Col>
                    <Col span="5">
                        <AutoComplete ref="bigv" placeholder="大V" style={style} api="bigvs/hint/" fieldname="realname" fieldvalue="id"/>
                    </Col>
                    <Col span="3">
                        <Select placeholder={this.types.placeholder} style={style} onSelect={this.handleSelect.bind(this, 'article_type')}>
                            {
                                this.types.data.map(x=> {
                                    return <Option value={x.value}>{x.text}</Option>;
                                })
                            }
                        </Select>
                    </Col>
                    <Col span="3">
                        <Select placeholder={this.status.placeholder} style={style} onSelect={this.handleSelect.bind(this, 'article_status')}>
                            {
                                this.status.data.map(x=> {
                                    return <Option value={x.value}>{x.text}</Option>;
                                })
                            }
                        </Select>
                    </Col>
                    <Col span="3">
                        {
                            this.props.disableModel ? (
                                <Select placeholder={this.enableModel.placeholder} defaultValue="不能" style={style}
                                        onSelect={this.handleSelect.bind(this, 'can_modeling')}>
                                    {
                                        this.enableModel.data.map(x=> {
                                            return <Option value={x.value}>{x.text}</Option>;
                                        })
                                    }
                                </Select>
                            ) : (
                                <Select placeholder={this.enableModel.placeholder} style={style} onSelect={this.handleSelect.bind(this, 'can_modeling')}>
                                    {
                                        this.enableModel.data.map(x=> {
                                            return <Option value={x.value}>{x.text}</Option>;
                                        })
                                    }
                                </Select>
                            )
                        }
                    </Col>
                    <Col span="3">
                        <Select placeholder={this.auditStatus.placeholder} style={style} onSelect={this.handleSelect.bind(this, 'approval_status')}>
                            {
                                this.auditStatus.data.map(x=> {
                                    return <Option value={x.value}>{x.text}</Option>;
                                })
                            }
                        </Select>
                    </Col>
                </Row>
                <Row type="flex" justify="space-around" style={{marginTop: '10px'}}>
                    <Col span="5">
                        <AutoComplete ref="modeler" placeholder="建模人" method="post" style={style} api="users/lists/" fieldname="username" fieldvalue="id"/>
                    </Col>
                    <Col span="5">
                        <AutoComplete ref="auditor" placeholder="审核人" method="post" style={style} api="users/lists/" fieldname="username" fieldvalue="id"/>
                    </Col>
                    <Col span="3">
                        <Select placeholder={this.diff.placeholder} style={style} onSelect={this.handleSelect.bind(this, 'has_wrong')}>
                            {
                                this.diff.data.map(x=> {
                                    return <Option value={x.value}>{x.text}</Option>;
                                })
                            }
                        </Select>
                    </Col>
                    <Col span="7">
                        <DateRangePicker ref="datePicker" style={style}/>
                    </Col>
                    <Col span="3">
                        <Button type="primary" style={style} onClick={this.handleSearch.bind(this)}>搜索</Button>
                    </Col>
                </Row>
            </div>
        );
    }
}

