/**
 * Created by chenjs on 16/3/10.
 */
import React, {Component} from 'react';
import {DatePicker} from 'antd';

export default class RangePicker extends Component {
    constructor() {
        super();
        this.state = {
            startValue: null,
            endValue: null
        };
    }

    disabledStartDate(startValue) {
        if (!startValue || !this.state.endValue) {
            return false;
        }
        return startValue.getTime() >= this.state.endValue.getTime();
    }

    disabledEndDate(endValue) {
        if (!endValue || !this.state.startValue) {
            return false;
        }
        return endValue.getTime() <= this.state.startValue.getTime();
    }

    onChange(field, value) {
        this.setState({
            [field]: value,
        });
    }

    render() {
        console.log(this.state.startValue);
        return (
            <div className="rangepicker-container" {...this.props}>
                <DatePicker disabledDate={this.disabledStartDate.bind(this)}
                            value={this.state.startValue}
                            placeholder="开始日期"
                            onChange={this.onChange.bind(this, 'startValue')}/>
                <DatePicker disabledDate={this.disabledEndDate.bind(this)}
                            value={this.state.endValue}
                            placeholder="结束日期"
                            onChange={this.onChange.bind(this, 'endValue')}/>
            </div>
        );
    }
}
