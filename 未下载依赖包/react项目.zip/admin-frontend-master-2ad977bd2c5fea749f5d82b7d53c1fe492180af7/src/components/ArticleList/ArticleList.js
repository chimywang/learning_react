/**
 * Created by chenjs on 16/3/10.
 */

import React, {Component} from 'react';
import SearchBar from './SearchBar';
import ResultTable from './ResultTable';
import './style.less';
import {Spin, Modal} from 'antd';
import {get, post} from '../../helper/httpHelper';

export default class ArticleList extends Component {

    constructor() {
        super();
        this.state = {params: null};
    }

    getArticleById(id) {
        const self = this;
        get({
            api: 'articles/' + id,
            s: x=> {
                self.props.showDetail && self.props.showDetail(x.data);
            },
            e: x=> {
                self.setState({
                    loading: false
                });
                Modal.error({
                    title: '提示',
                    content: x
                });
            }
        });
    }

    handleSearch(params) {
        this.setState({params: params});
    }

    handleClick(id) {
        this.getArticleById(id);
    }

    render() {
        return (
            <div>
                <SearchBar {...this.props} callBack={this.handleSearch.bind(this)}/>
                <ResultTable {...this.props} params={this.state.params} callBack={this.handleClick.bind(this)}/>
            </div>
        );
    }
}
