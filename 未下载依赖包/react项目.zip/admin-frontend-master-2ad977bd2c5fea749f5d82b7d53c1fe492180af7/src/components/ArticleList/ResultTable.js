/**
 * Created by chenjs on 16/3/10.
 */

import React, {Component} from 'react';
import {Table, Modal, Spin} from 'antd';
import {post} from '../../helper/httpHelper';
import DateHelper from '../../helper/dateHelper';
import './style.less';

export default class ResultTable extends Component {

    constructor() {
        super();
        this.state = {
            data: [],
            pagination: {
                showQuickJumper: true,
                pageSize: 12
            },
            loading: false
        };
        this.columns = [{
            title: '标题',
            dataIndex: 'title',
            width: '300px',
            sorter: true
        }, {
            title: '原发布时间',
            dataIndex: 'publish_on',
            render: x=> {
                return DateHelper.formatDate(x);
            },
            sorter: true
        }, {
            title: '大V',
            dataIndex: 'Bigv',
            render: x=>x && x.realname || '',
            sorter: true
        }, {
            title: '类型',
            dataIndex: 'article_type',
            render: x=>x == 1 ? '预测型' : (x == 2 ? '资讯型' : ''),
            sorter: true
        }, {
            title: '文章状态',
            dataIndex: 'article_status',
            render: x=>x == 1 ? '正常' : (x == 2 ? '隐藏' : ''),
            sorter: true
        }, {
            title: '能否建模',
            dataIndex: 'can_modeling',
            render: x=> {
                return x == 1 ? '能' : (x == 2 ? '不能' : '待定');
            },
            sorter: true
        }, {
            title: '审核状态',
            dataIndex: 'approval_status',
            render: x=> {
                switch (x) {
                case '1':
                    return '待判断';
                    break;
                case '2':
                    return '建模中';
                    break;
                case '3':
                    return '待审核';
                    break;
                case '4':
                    return '审核中';
                    break;
                case '5':
                    return '已审核';
                    break;
                default:
                    break;
                }
            },
            sorter: true
        }, {
            title: '差错',
            dataIndex: 'has_wrong',
            sorter: true
        }, {
            title: '模型数',
            dataIndex: 'has_wrong',
            sorter: true
        }, {
            title: '建模人',
            dataIndex: 'Creator',
            render: x=> x && x.username || '',
            sorter: true
        }, {
            title: '审核人',
            dataIndex: 'Auditor',
            render: x=> x && x.username || '',
            sorter: true
        }];
        this.params = {};
    }

    handleClick(record) {
        this.props.callBack && this.props.callBack(record.id);
    }

    handleTableChange(pagination, filters, sorter) {
        const pageIndex = pagination.current;
        const offset = (pageIndex - 1) * 12;
        this.params.limit = 12;
        this.params.offset = offset;
        this.params.current = pageIndex;
        if (sorter.field && sorter.order) {
            let order;
            if (sorter.field == 'big') {
                order = sorter.order.indexOf('desc') > -1 ? 'bigv_id desc' : 'bigv_id asc';
            } else if (sorter.field == 'creator') {
                order = sorter.order.indexOf('desc') > -1 ? 'model_creator_id desc' : 'model_creator_id asc';
            } else if (sorter.field == 'auditor') {
                order = sorter.order.indexOf('desc') > -1 ? 'model_auditor_id desc' : 'model_auditor_id asc';
            } else {
                order = sorter.order.indexOf('desc') > -1 ? sorter.field + ' desc' : sorter.field + ' asc';
            }
            this.params.order = order;
        } else {
            this.params.order = '';
        }
        this.getAllArticle();
    }

    componentWillReceiveProps(p) {
        if (p.params) {
            const self = this;
            Object.getOwnPropertyNames(p.params).map(x=> {
                self.params[x] = p.params[x];
            });
            self.params.limit = 12;
            self.params.offset = 0;
            self.params.current = 1;
            this.getAllArticle();
        }
    }

    componentDidMount() {
        this.params.limit = 12;
        this.params.current = 1;
        this.params.offset = 0;
        if (this.props.disableModel) {
            this.params.can_modeling = 2;
        }
        this.getAllArticle();
    }

    getAllArticle() {
        const self = this;
        self.setState({
            loading: true
        });
        post({
            api: 'articles/all',
            d: self.params ? self.params : '',
            s: x=> {
                self.setState({
                    loading: false,
                    data: x.data.rows,
                    pagination: {
                        current: self.params.current,
                        total: x.data.count,
                        showTotal: ()=> {
                            return '共' + x.data.count + '条';
                        }
                    }
                });
            },
            e: (x)=> {
                self.setState({
                    loading: false
                });
                Modal.error({
                    title: '提示',
                    content: x
                });
            }
        });
    }

    render() {
        return (
            <Table className="table-container"
                   loading={this.state.loading}
                   columns={this.columns}
                   dataSource={this.state.data}
                   pagination={this.state.pagination}
                   onChange={this.handleTableChange.bind(this)}
                   onRowClick={this.handleClick.bind(this)}/>
        );
    }
}
