/**
 * Created by chenjs on 16/3/10.
 */

import React, {Component} from 'react';
import './style.less';

export default class Footer extends Component {


    render() {
        return (
            <div className="footer-container">
                <span className="title">嘉实财富版权所有 2004-2016 ICP证:沪B2-20150087</span>
            </div>
        );
    }
}
