/**
 * Created by qinmy on 16/3/10.
 */
import {Button} from 'antd';
import React, {Component} from 'react';
import {Table} from 'antd';
import {Modal} from 'antd';
import UserInfo from '../UserInfo/UserInfo';
import {get, post} from '../../helper/httpHelper';
import EditUserInfo from '../UserInfo/EditUserInfo';
import ResetPwd from '../UserInfo/ResetPwd';
import './style.less';

export default class Config extends Component {

    constructor() {
        super();
        this.state = {
            data: []
        };
    }

    componentDidMount() {
        this.getAllUser();
    }

    showNewModal() {
        this.refs.modal1.showModal();
    }

    showEditModal(id, name, address, role, states) {
        this.refs.modal2.showModal(id, name, address, role, states);
        console.log('id：' + id + '用户名：' + name + '邮箱：' + address + '角色：' + role + '状态：' + states);
    }

    showResetModal(id) {
        this.refs.modal3.showModal(id);
    }

    getAllUser() {
        const self = this;
        post({
            api: 'users/lists',
            d: {page_num: '', page_size: ''},
            s: x=> {
                self.setState({
                    data: x.data.rows
                });
            },
            e: ()=> {
                Modal.error({
                    title: '提示',
                    content: '获取文章列表失败,请刷新重试'
                });
            }
        });

    }

    render() {
        const style = {margin: '5px'};
        const config = this;
        const columns = [{
            title: '编号',
            render(text, record, index) {
                return (
                    <span>
                        <span id="num">
                            {index + 1}
                        </span>
                    </span>
                );
            },
        }, {
            title: '用户名',
            dataIndex: 'username',
        }, {
            title: '邮箱',
            dataIndex: 'email',
        }, {
            title: '角色',
            dataIndex: 'user_role_name',
        }, {
            title: '状态',
            dataIndex: 'user_state_name',
        }, {
            title: '操作',
            render(text, record) {
                return (
                    <span>
                        <span id="edit" onClick={config.showEditModal.bind(config, record.id, record.username, record.email,
                        record.user_role_name, record.user_state_name)}>
                        编辑
                        </span>
                        <span className="ant-divider"></span>
                        <span id="reset" onClick={config.showResetModal.bind(config, record.id)}>
                        重置密码
                        </span>
                    </span>
                );
            }
        }];

        return (
            <div className="newObj">
                <Button id="new" type="primary" style={style} onClick={this.showNewModal.bind(this)}>
                    新建
                </Button>
                <UserInfo newCallBack={this.getAllUser.bind(this)} ref="modal1"/>
                <EditUserInfo editCallBack={this.getAllUser.bind(this)} ref="modal2"/>
                <ResetPwd ref="modal3"/>
                <Table dataSource={this.state.data} columns={columns}/>
            </div>
        );
    }
}
