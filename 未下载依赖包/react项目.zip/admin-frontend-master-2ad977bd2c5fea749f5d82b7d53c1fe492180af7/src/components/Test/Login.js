/**
 * Created by lenovo-pc on 2016/3/14.
 */
/**
 * Created by chenjs on 16/3/9.
 */

import React, {Component} from 'react';
import './style.less';
import { Form, Input, Button, Checkbox } from 'antd';
const FormItem = Form.Item;

export default class Login extends Component {

    handleSubmit(e) {
        e.preventDefault();
        console.log('收到表单值：');
    }
    render() {
        return (
            <Form inline>
                <FormItem
                    label="账户：">
                    <Input placeholder="请输入账户名" width="2000px"/>
                </FormItem>

                <br/>

                <FormItem
                    label="密码：">
                    <Input type="password" placeholder="请输入密码"/>
                </FormItem>

                <FormItem
                    label="警告校验："
                    labelCol={{ span: 5 }}
                    wrapperCol={{ span: 12 }}
                    hasFeedback
                    validateStatus="warning">
                    <Input defaultValue="前方高能预警" id="warning" />
                </FormItem>

                <br/>
                <FormItem>
                <label className="ant-checkbox-inline">
                    <Checkbox/>记住我
                </label>
            </FormItem>

                <Button type="primary" htmlType="submit" onClick={this.handleSubmit}>登录</Button>
            </Form>
        );
    }
}
