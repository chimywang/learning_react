/**
 * Created by chenjs on 16/3/14.
 */

import React, {Component} from 'react';
import ArticleDetail from '../ArticleDetail/ArticleDetail';
import ArticleList from '../ArticleList/ArticleList';
import {Spin, Modal} from 'antd';
import config from '../../config.js';
import {get} from '../../helper/httpHelper';

export default class ArticlePage extends Component {

    constructor() {
        super();
        this.state = {
            loading: false,
            status: 0,
            article: ''
        };
    }

    showDetail(article) {
        this.setState({
            status: 1,
            article: article
        });
    }

    showList() {
        this.setState({
            status: 0
        });
    }

    componentWillMount() {
        if (config.lock_article_id) {
            this.setState({
                status: 2,
                article: ''
            });
        }
    }

    componentDidMount() {
        if (config.lock_article_id) {
            this.setState({
                loading: true
            });
            const self = this;
            get({
                api: 'articles/' + config.lock_article_id,
                s: x=> {
                    this.setState({
                        status: 1,
                        article: x.data,
                        loading: false
                    });
                },
                e: x=> {
                    self.setState({
                        loading: false
                    });
                    Modal.error({
                        title: '提示',
                        content: x
                    });
                }
            });
        }
    }

    render() {
        let content = '';
        if (this.state.status == 0) {
            content = <ArticleList showDetail={this.showDetail.bind(this)} {...this.props}/>;
        } else if (this.state.status == 1) {
            content = <ArticleDetail article={this.state.article} showDetail={this.showDetail.bind(this)} showList={this.showList.bind(this)}/>;
        }

        return (
            <Spin spining={this.state.loading}>
                {content}
            </Spin>
        );
    }
}
