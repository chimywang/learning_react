/**
 * Created by lenovo-pc on 2016/3/14.
 */
import React from 'react';
import './style.less';
import {Spin, Modal} from 'antd';
import {get, post} from '../../helper/httpHelper';
import config from '../../config.js';

const Login = React.createClass({

    componentWillMount() {
        this.verifyTokenState();
    },
    componentDidMount() {
    },

    verifyTokenState() {
        const self = this;
        get({
            api: 'current_user',
            s: x=> {
                if (x.data.is_superuser) {
                    config.user_Permission = 2;
                } else if (x.data.is_advanced) {
                    config.user_Permission = 1;
                } else {
                    config.user_Permission = 0;
                }
                self.saveUser(x);
                self.props.loginCallBack && self.props.loginCallBack(x.data.username);
            },

            e: () => {
                self.setState({
                    opacity: 1
                });
            }
        });
    },

    handleSubmit() {
        this.userName = this.refs.userName.value;
        this.userPassword = this.refs.userPassword.value;
        if (this.userName === '') {
            Modal.error({
                title: '提示',
                content: '帐号不能为空'
            });
        } else if (this.userPassword === '') {
            Modal.error({
                title: '提示',
                content: '密码不能为空'
            });
        } else {
            this.executeLogin(this.userName, this.userPassword);
        }
    },

    getInitialState() {
        return {
            opacity: 0
        };
    },

    executeLogin(name, password) {
        const self = this;
        this.setState({loading: !this.state.loading});
        post({
            api: 'signin',
            d: {email: name, password: password},
            s: x=> {
                self.saveUser(x);
                self.props.loginCallBack && self.props.loginCallBack(x.data.username);
            },
            e: x=> {
                Modal.error({
                    title: '提示',
                    content: x
                });
            }
        });
    },

    saveUser(x) {
        x.data.is_superuser ? config.user_Permission = 2 : x.data.is_advanced ? config.user_Permission = 1 :
            config.user_Permission = 0;
        config.user_name = x.data.username;
        config.user_id = x.data.id;
        config.lock_article_id = x.data.lock_article_id;
    },

    render()
    {
        var btnLayout = {style: {width: '100%', border: '1px solid #fff', color: '#fff', height: '30px'}};
        return (
            <div className="login-container" style={{opacity: this.state.opacity}}>
                <div className="mark"></div>
                <div className="login-background">
                    <ul className="input-ul">
                        <li className="li-name">
                            <input placeholder="请输入邮箱" ref="userName" className="input-style"/>
                        </li>
                        <li className="li-password">
                            <input type="password" placeholder="请输入密码" ref="userPassword" className="input-style"/>
                        </li>
                        <li>
                            <p {...btnLayout} onClick={this.handleSubmit} className="button"> 登 录 </p>
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
});

export default Login;
