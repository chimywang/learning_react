/**
 * Created by chenjs on 16/3/15.
 */

import React, {Component} from 'react';
import './style.less';

export default class MyTextInput extends Component {

    constructor() {
        super();
        this.state = {
            value: ''
        };
    }

    getValue() {
        return this.state.value;
    }

    handleChange() {
        this.setState({
            value: this.props.textarea ? this.refs.t.value : this.refs.i.value
        });
    }

    componentWillMount() {
        this.setState({
            value: this.props.defaultValue
        });
    }

    componentWillReceiveProps(p) {
        this.setState({
            value: p.defaultValue
        });
    }

    render() {
        const disable = {disabled: this.props.disabled || false};
        return (
            <span className="my-input">
                {
                    this.props.unableedit ? <p className="ant-form-text">{this.state.value}</p> :
                        (
                            this.props.textarea ?
                                <textarea ref="t" type="textarea" rows="3" onChange={this.handleChange.bind(this)} {...disable}>
                                    {this.state.value}</textarea> :
                                <input ref="i" type="text" placeholder={this.props.placeholder} {...disable}
                                       value={this.state.value}
                                       onChange={this.handleChange.bind(this)}/>
                        )
                }
            </span>
        );
    }
}
