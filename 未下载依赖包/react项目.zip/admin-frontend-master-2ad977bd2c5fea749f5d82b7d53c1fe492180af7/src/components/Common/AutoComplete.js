/**
 * Created by chenjs on 16/3/14.
 */

/**
 * Created by chenjs on 16/3/9.
 */

import React, {Component} from 'react';
import {Select} from 'antd';
import {get, post} from '../../helper/httpHelper';
const Option = Select.Option;

export default class AutoComplete extends Component {

    constructor() {
        super();
        this.state = {
            data: []
        };
        this.timeout = null;
        this.nameAndValue = ['', ''];
        this.lastNameAndValue = ['', ''];
        this.selectCallBack = false;
    }

    fetch(value) {
        if (this.timeout) {
            clearTimeout(this.timeout);
            this.timeout = null;
        }
        this.inputValue = value;

        const fake = ()=> {
            const self = this;
            if (self.props.method === 'post') {
                post({
                    api: this.props.api,
                    d: {hint: value},
                    s: (resp)=> {
                        if (self.inputValue === value) {
                            const result = resp.data;
                            const data = [];
                            result.forEach((r) => {
                                data.push({
                                    value: r[this.props.fieldvalue],
                                    text: r[this.props.fieldname],
                                });
                            });
                            self.setState({data});
                        }
                    }
                });
            } else {
                get({
                    api: this.props.api + value,
                    s: (resp)=> {
                        if (self.inputValue === value) {
                            const result = resp.data;
                            const data = [];
                            result.forEach((r) => {
                                data.push({
                                    value: r[this.props.fieldvalue],
                                    text: r[this.props.fieldname],
                                });
                            });
                            self.setState({data});
                        }
                    }
                });
            }
        };

        this.timeout = setTimeout(fake, 300);
    }

    handleChange(value, label) {
        this.nameAndValue[0] = label;
        this.nameAndValue[1] = value;

        if (this.selectCallBack) {
            this.lastNameAndValue[0] = label;
            this.lastNameAndValue[1] = value;
            this.selectCallBack = false;
        } else {
            if (label == this.lastNameAndValue[0]) {
                this.nameAndValue[1] = this.lastNameAndValue[1];
            } else {
                this.nameAndValue[1] = '';
                this.fetch(value);
            }
        }
    }

    handleSelect() {
        this.selectCallBack = true;
    }

    getValue() {
        return this.nameAndValue;
    }

    componentWillMount() {
        if (this.props.defaultValue) {
            this.nameAndValue[0] = this.lastNameAndValue[0] = this.props.defaultValue[0];
            this.nameAndValue[1] = this.lastNameAndValue[1] = this.props.defaultValue[1];
        }
    }

    render() {
        const options = this.state.data ? this.state.data.map(d => <Option value={d.value}>{d.text}</Option>) : '';
        return (
            <Select {...this.props}
                combobox
                defaultValue={this.props.defaultValue ? this.props.defaultValue[0] : ''}
                searchPlaceholder={this.props.placeholder}
                notFoundContent=""
                defaultActiveFirstOption={false}
                showArrow={false}
                filterOption={false}
                onSelect={this.handleSelect.bind(this)}
                onChange={this.handleChange.bind(this)}>
                {options}
            </Select>
        );
    }
}
