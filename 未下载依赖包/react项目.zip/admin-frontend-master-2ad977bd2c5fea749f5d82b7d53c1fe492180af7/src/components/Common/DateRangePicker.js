/**
 * Created by David on 16/3/14.
 */
import React, {Component} from 'react';
import {DatePicker} from 'antd';
import './style.less';

export default class DateRangePicker extends Component {
    constructor() {
        super();
        this.state = {
            startValue: null,
            endValue: null
        };
    }

    clearTime() {
        this.state = {
            startValue: null,
            endValue: null
        };
        this.setState(this.state);
    }

    disabledStartDate(startValue) {
        if (!startValue || !this.state.endValue) {
            return false;
        }
        return startValue.getTime() >= this.state.endValue.getTime();
    }

    disabledEndDate(endValue) {
        if (!endValue || !this.state.startValue) {
            return false;
        }
        return endValue.getTime() <= this.state.startValue.getTime();
    }

    onChange(field, value) {
        this.state[field] = value;
        this.setState({
            [field]: value,
        });
        this.props.pickerFinish && this.props.pickerFinish(this.state);
    }

    getValue() {
        return {
            start: this.state.startValue || '',
            end: this.state.endValue || ''
        };
    }

    render() {
        return (
            <div className="dateRangepicker-container" {...this.props}>
                <DatePicker disabledDate={this.disabledStartDate.bind(this)}
                            value={this.state.startValue}
                            placeholder="开始日期"
                            onChange={this.onChange.bind(this, 'startValue')}/>
                {this.props.showMiddle ? '至' : ''}
                <DatePicker disabledDate={this.disabledEndDate.bind(this)}
                            value={this.state.endValue}
                            placeholder="结束日期"
                            onChange={this.onChange.bind(this, 'endValue')}/>
            </div>
        );
    }
}
