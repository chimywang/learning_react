import React from 'react';
import Header from '../components/Header/Header';
import Footer from '../components/Footer/Footer';
import Login from '../components/Login/Login';
import MainPage from '../components/MainPage/MainPage';
import 'antd/lib/index.css';

const App = React.createClass({

    getInitialState() {
        return {
            isLogin: false,
            userName: '',
            outButton: ''
        };
    },

    handleLogin(name) {
        this.setState({
            isLogin: true,
            userName: name,
            outButton: '退出'
        });
    },

    handleOut() {
        this.setState({
            isLogin: false,
            userName: '',
            outButton: ''
        });
    },
    handleEditorChange(newCode) {
        this.setState({
            code: newCode
        });
    },

    render() {
        return (
            <div>
                <Header outCallBack={this.handleOut} userName={this.state.userName} outButton={this.state.outButton}/>
                {
                    this.state.isLogin ?
                        <MainPage/> :
                        [<Login loginCallBack={this.handleLogin}/>, <Footer />]
                }
            </div>
        );
    }
});

export default App;
