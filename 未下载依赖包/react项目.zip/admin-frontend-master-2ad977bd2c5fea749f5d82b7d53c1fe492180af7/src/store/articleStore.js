/**
 * Created by chenjs on 16/3/17.
 */

import Reflux from 'reflux';
import {articleAction} from '../actions/Actions';
import {post, get, patch} from '../helper/httpHelper';

export default Reflux.createStore({
    listenables: articleAction,
    init: function() {

    },
    onGetArticles(data) {
        const self = this;
        post({
            api: 'articles/all',
            d: data,
            s: x=> {
                self.trigger({
                    action: 'getArticles',
                    response: x
                });
            }
        });
    },
    onGetArticle(id) {
        const self = this;
        get({
            api: 'articles/' + id,
            s: x=> {
                self.trigger({
                    action: 'getArticle',
                    response: x
                });
            }
        });
    },
    onEditArticle(id, data) {
        const self = this;
        patch({
            api: 'articles/' + id,
            d: data,
            s: x=> {
                self.trigger(x);
            }
        });
    }
});
