module.exports = function(gulp) {
    gulp.task('custom-task', function() {
        console.log('custom task done!');
    });
};
