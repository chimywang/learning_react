/**
 * Created by Meric on 2016/11/18.
 */
import React from 'react';
import $ from 'jquery';

export default class ShapeCanvas extends React.Component {
	constructor(props){
		super(props);
		this.flag = false;
		this.oW = 0;//线结束点X轴
		this.oH = 0;//线结束点Y轴
		this.mouseMove = this.mouseMove.bind(this);
		this.click = this.click.bind(this);
		this.drawShape = this.drawShape.bind(this);
		this.setWidthAndHeight = this.setWidthAndHeight.bind(this);
		this.getMousePos = this.getMousePos.bind(this);
	}
	static defaultProps = {
		width: 50,
		height:20,
		left:50,
		top:20,
		obj:{
			startx:0,
			starty:0
		},
	}
	canvasObj = null
	componentDidMount() {
		this.canvasObj = this.refs.canvas.getContext("2d");
		this.refs.container.style.width = this.props.width+"px";
		this.refs.container.style.height = this.props.height+"px";
		this.refs.container.style.top = this.props.top+"px";
		this.refs.container.style.left = this.props.left+"px";

		this.refs.canvas.width = this.props.width;
		this.refs.canvas.height = this.props.height;
	}
	setWidthAndHeight(w,h,mw,mh) {
		//mw 为鼠标距离canvas标签的左边距离
		var shapeWidth = this.getShapeWidth(this.props.obj.startx);
		var shapeHeight = this.getShapeHeight(this.props.obj.starty);
		var minWidth = mw+shapeWidth;
		var minHeight = mh+shapeHeight;
		var mtL = this.oW<this.props.obj.startx;//鼠标往左运动
		var mtR = this.oW>this.props.obj.startx;//鼠标往右运动
		var mtT = this.oH<this.props.obj.starty;//鼠标往上运动
		var mtB = this.oH>this.props.obj.starty;//鼠标往下运动
		/**
		 * 最小宽度大于现在设置的宽度,线的长度小于容器的一半
		 */
		if(minHeight>h&&h/2>minHeight){
			this.refs.container.style.height = minHeight + "px";
			this.refs.canvas.height = minHeight;
		}else{
			if(mtT){
				this.refs.container.style.height = minHeight+50 + "px";
				this.refs.canvas.height = minHeight+50;
			}else{
				if(this.refs.canvas.height/2<this.props.obj.starty){
					this.refs.container.style.height = this.props.obj.starty+shapeHeight+50 + "px";
					this.refs.canvas.height = this.props.obj.starty+shapeHeight+50;
				}else{
					this.refs.container.style.height = shapeHeight+this.props.obj.starty+50 + "px";
					this.refs.canvas.height = shapeHeight+this.props.obj.starty+50;
				}
			}

		}
		if (minWidth > w&&w / 2 > shapeWidth) {
			if(mtR){
				this.refs.container.style.width = this.props.obj.startx+shapeWidth+50 + "px";
				this.refs.canvas.width = this.props.obj.startx+shapeWidth+50;
			}

		} else {
			if (mtR) {
				if(this.props.obj.startx>shapeWidth+mw){
					this.refs.container.style.width = this.props.obj.startx+shapeWidth+50 + "px";
					this.refs.canvas.width = this.props.obj.startx+shapeWidth+50;
				}else {
					if(this.refs.canvas.width/2<this.props.obj.startx){
						this.refs.container.style.width = this.props.obj.startx+shapeWidth+50 + "px";
						this.refs.canvas.width = this.props.obj.startx+shapeWidth+50;
					}else{
						this.refs.container.style.width = w + "px";
						this.refs.canvas.width = w;
					}
				}
			}
		}
	}
	getShapeWidth(endx){
		return Math.abs(this.oW-endx);
	}
	getShapeHeight(endy){
		return Math.abs(this.oH-endy);
	}
	drawShape(startX,startY,endX,endY) {
		this.oW = endX ;
		this.oH = endY;
		this.canvasObj.strokeStyle = "#f00";
		this.canvasObj.lineWidth = 3;
		this.canvasObj.clearRect(0,0,this.refs.canvas.width,this.refs.canvas.height);
		this.canvasObj.beginPath();
		this.canvasObj.moveTo(startX,startY);
		this.canvasObj.lineTo(endX,endY);
		this.canvasObj.stroke();
	}
	mouseMove(e){
		var width,height;
		if(this.flag){
			if((Math.abs(e.clientX)+this.props.obj.startx)>=50){
				width = Math.abs(e.clientX)+50;
			}
			if((Math.abs(e.clientY)+this.props.obj.starty)>=50){
				height = Math.abs(e.clientY)+50;
			}
			var mousePos = this.getMousePos(e.target,e);
			this.setWidthAndHeight(width,height,mousePos.x,mousePos.y);
			this.drawShape(this.props.obj.startx,this.props.obj.starty,mousePos.x,mousePos.y);
		}
	}
	click(e){
		if(!this.flag){
			var mousePos = this.getMousePos(e.target,e);
			this.props.obj.startx = mousePos.x
			this.props.obj.starty = mousePos.y;
		}
		this.flag = !this.flag;
	}
	getMousePos(canvas, evt) {
		var rect = canvas.getBoundingClientRect();
		return {
			x: evt.clientX - rect.left * (canvas.width / rect.width),
			y: evt.clientY - rect.top * (canvas.height / rect.height)
		}
	}
	render() {
		return (
			<div ref="container" style={
			{
				position:'absolute',
				border:'1px solid #ccc',
				zIndex:3
			}
			}>
				<canvas ref="canvas" onMouseMove={this.mouseMove} onClick={this.click}>your liulanqi not support Canvas</canvas>
			</div>
		)
	}
}