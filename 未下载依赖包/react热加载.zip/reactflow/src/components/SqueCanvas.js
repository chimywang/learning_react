/**
 * Created by Meric on 2016/11/19.
 */
import React from 'react';

export default class SqueCanvas extends React.Component {
	constructor(props){
		super(props);
		this.clickPoint = this.clickPoint.bind(this);
	}
	canvasObj = null
	componentDidMount(){
		this.canvasObj = this.refs.canvas.getContext("2d");
		this.draw(0,0,100,100);
	}
	draw(x,y,w,h) {
		this.canvasObj.fillStyle="#ccc";
		this.canvasObj.strokeRect(x, y, w,h);
	}
	clickPoint(e){
		console.log('click')
		this.props.addShape(e.clientX,e.clientY);
	}
	render() {
		return (
			<div style={
			{
				width:'100px',
				height:'100px',
				position:'absolute',
				top:'100px',
				left:'100px',
				zIndex:2
			}
			}>
				<canvas ref="canvas" width={100} height={100} onClick={this.clickPoint}>not support</canvas>
			</div>
		);
	}
}