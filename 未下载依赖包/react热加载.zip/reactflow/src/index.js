/**
 * Created by Meric on 2016/11/18.
 */
import React from 'react';
import { render } from 'react-dom';
import ShapeCanvas from './components/ShapeCanvas';
import SqueCanvas from './components/SqueCanvas';

class App extends React.Component {
	constructor(props){
		super(props);
		this.addLine = this.addLine.bind(this);
		this.getGetLines = this.getGetLines.bind(this);
		this.state = {
			lineMap:[]
		}
	}
	addLine(x,y){
		var newLine = {
			id:"line-id"+Math.random(),
			nodeObj:<ShapeCanvas left={x} top={y}/>,
		};
		var that = this;
		this.setState({
			lineMap: that.state.lineMap.concat(newLine)
		});
	}
	getGetLines(){
		console.log(this.state)
		return this.state.lineMap ? this.state.lineMap.map(function (item) {
			return item.nodeObj;
		}): null;
	}
	render() {
		return (
			<div style={{position:'relative'}}>
				react flow 11
				<ShapeCanvas />
				<SqueCanvas addShape={this.addLine}/>
				{
						this.getGetLines()
				}
			</div>
		);
	}
}
render(
	<App/>,
	document.getElementById('app')
);