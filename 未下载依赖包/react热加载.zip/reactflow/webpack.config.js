/**
 * Created by Meric on 2016/11/18.
 */
var path = require('path');
var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
	devtool: 'eval',
	entry:[
		'webpack-dev-server/client?http://localhost:3000',
		'webpack/hot/dev-server',
		'./src/index.js'
	],//入口文件
	resolve: {
		extensions:['','.js','.jsx'],
	},
	output:{
		path:path.resolve(__dirname,'./assets'),//输出路径
		filename:'[name].js',//输出文件名
		publicPath:'/'
	},
	module:{
		loaders:[
			{
				test:/\.js$/,
				loader:'babel',
				exclude:/node_modules/,
				query: { presets: ['react','es2015','stage-0'] }
			},
			{
				test:/\.css$/,
				loader:"style-loader!css-loader",
			}
		]
	},
	devServer:{
		devtool:'eval',
		hot:true,
		inline:true,
		publicPath:'',
		port:3000,
		host:'localhost',
		stats:{cached:false,colors:true}
	},
	plugins:[
		new webpack.optimize.OccurenceOrderPlugin(),
		new webpack.NoErrorsPlugin(),
		new webpack.HotModuleReplacementPlugin(),
		new HtmlWebpackPlugin({
			title: 'your app title',
			template: './index.html',
			inject:'body',
			hash:true,
		})
	]
}